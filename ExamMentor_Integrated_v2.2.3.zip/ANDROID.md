# ANDROID.md – csomagolási stratégia

## MVP döntés (ajánlott)
**PWA first** ✅
- leggyorsabb út (0 natív build)
- azonnali teszt Androidon (Chrome → Add to Home screen)
- ugyanaz a kód bázis desktopra (Tauri) és webre

Ha Play Store / natív API kell: **Capacitor** a 2. fázisban.

## PWA vs Capacitor – gyors döntési táblázat

| Igény | PWA | Capacitor |
|---|---:|---:|
| 1 nap alatt MVP | ✅ | ❌ |
| Play Store | ⚠️ (TWA) | ✅ |
| Offline támogatás | ✅ | ✅ |
| Fájlkezelés (share sheet, file pickers) | ⚠️ | ✅ |
| Background tasks | ⚠️ | ✅ |
| Push notifications | ✅ (korlátozott) | ✅ |

## PWA MVP lépések
1) Backend legyen elérhető HTTPS-en (vagy fejlesztésben `localhost`).
2) Frontend: `frontend/` → `npm run build`.
3) Telefonon nyisd meg a webappot Chrome-ban.
4) Menü → **Add to Home screen**.

## Capacitor (2. fázis) minimál guide
> Ezt akkor érdemes, ha Play Store kell vagy natív file API-k.

1) Frontend build:
```bash
cd frontend
npm install
npm run build
```

2) Capacitor init:
```bash
npm install @capacitor/core @capacitor/cli
npx cap init ExamMentor com.exammentor.app
```

3) Android platform:
```bash
npm install @capacitor/android
npx cap add android
```

4) Web assets sync:
```bash
npx cap sync android
```

5) Android Studio:
```bash
npx cap open android
```

## Backend URL / CORS
- `CORS_ALLOW_ORIGINS` állítsd a webapp originre.
- Ha Androidon natív wrapperből hívod: jellemzően `capacitor://localhost` vagy `http://localhost` origin.

## Ajánlott irány (fix)
- **Most**: PWA + job polling + artifact download ✅
- **Később**: Capacitor, ha kell Play Store / natív API
