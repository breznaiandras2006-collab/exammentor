# main.py
from __future__ import annotations

import hashlib
import json
import logging
import os
import traceback
import uuid
import io
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.parse import quote_plus
from typing import Any

from fastapi import FastAPI, Request, UploadFile, File, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, FileResponse, PlainTextResponse
from fastapi.exceptions import RequestValidationError
from starlette.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from fastapi.middleware.cors import CORSMiddleware

from db import (init_db, list_documents, get_document, insert_document,
                search_documents, list_notes, get_note, insert_note,
                update_note, search_notes, get_all_settings, get_setting,
                set_setting,
                # artifacts
                insert_artifact, list_artifacts, list_artifacts_for_document, get_artifact,
                detach_artifact_from_jobs, delete_artifact_row, list_artifacts_older_than,
                detach_document_from_notes, delete_jobs_for_document, delete_document_row,
                # jobs
                insert_job, update_job, get_job, list_jobs)

# Import module for feature detection (optional functions may exist depending on integration phase)
import db as db_mod
from tools import (safe_filename, make_snippet, extract_text_from_pdf, extract_text_from_pdf_path,
                   pdf_page_count, pdf_page_count_path, compress_pdf_bytes, split_pdf_bytes,
                   parse_ranges, pdf_to_images_zip_bytes, images_to_pdf_bytes, zip_files_bytes)
from queue_backend import submit_job

logger = logging.getLogger("exammentor")


app = FastAPI()


def _get_request_id(request: Request) -> str:
    rid = (request.headers.get("X-Request-Id") or "").strip()
    return rid or uuid.uuid4().hex


def _is_api_request(request: Request) -> bool:
    return (request.url.path or "").startswith("/api/")


def _json_error(request: Request,
                *,
                status_code: int,
                code: str,
                message: str,
                details: object | None = None):
    rid = getattr(request.state, "request_id", None) or _get_request_id(request)
    payload: dict = {
        "ok": False,
        "error": {
            "code": code,
            "message": message,
            "request_id": rid,
        },
    }
    if details is not None:
        payload["error"]["details"] = details
    return JSONResponse(payload, status_code=int(status_code), headers={"X-Request-Id": rid})


@app.middleware("http")
async def request_id_middleware(request: Request, call_next):
    rid = _get_request_id(request)
    request.state.request_id = rid
    logger.info("rid=%s %s %s", rid, request.method, request.url.path)
    response = await call_next(request)
    response.headers["X-Request-Id"] = rid
    return response


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    if _is_api_request(request):
        return _json_error(request,
                           status_code=int(exc.status_code),
                           code="http_error",
                           message=str(exc.detail))
    rid = getattr(request.state, "request_id", None) or _get_request_id(request)
    return PlainTextResponse(str(exc.detail), status_code=int(exc.status_code), headers={"X-Request-Id": rid})


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    if _is_api_request(request):
        return _json_error(request,
                           status_code=422,
                           code="validation_error",
                           message="Invalid request",
                           details=exc.errors())
    rid = getattr(request.state, "request_id", None) or _get_request_id(request)
    return PlainTextResponse("Validation error", status_code=422, headers={"X-Request-Id": rid})


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    logger.exception("Unhandled error rid=%s", getattr(request.state, "request_id", ""))
    if _is_api_request(request):
        return _json_error(request,
                           status_code=500,
                           code="internal_error",
                           message="Internal server error")
    rid = getattr(request.state, "request_id", None) or _get_request_id(request)
    return PlainTextResponse("Server error", status_code=500, headers={"X-Request-Id": rid})

# CORS (for PWA / desktop wrappers)
# - In production, set CORS_ALLOW_ORIGINS env var, e.g.: "https://app.example.com,https://admin.example.com"
_cors_env = (os.getenv("CORS_ALLOW_ORIGINS") or "*").strip()
if _cors_env == "*":
    allow_origins = ["*"]
else:
    allow_origins = [o.strip() for o in _cors_env.split(",") if o.strip()]

app.add_middleware(
    CORSMiddleware,
    allow_origins=allow_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

BASE_DIR = Path(__file__).parent
UPLOAD_DIR = BASE_DIR / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

# Note image uploads live under uploads/images (do NOT expose raw uploaded PDFs)
IMAGE_DIR = UPLOAD_DIR / "images"
IMAGE_DIR.mkdir(parents=True, exist_ok=True)

ARTIFACT_DIR = BASE_DIR / "artifacts"
ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)

JOB_INPUT_DIR = UPLOAD_DIR / "_job_inputs"
JOB_INPUT_DIR.mkdir(parents=True, exist_ok=True)

ARTIFACT_RETENTION_DAYS = max(1, int(os.getenv("ARTIFACT_RETENTION_DAYS") or "7"))

# logging
LOG_LEVEL = (os.getenv("LOG_LEVEL") or "INFO").upper()
logging.basicConfig(
    level=LOG_LEVEL,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)

# uploads
MAX_UPLOAD_MB = max(1, int(os.getenv("MAX_UPLOAD_MB") or "100"))
MAX_UPLOAD_BYTES = MAX_UPLOAD_MB * 1024 * 1024

MAX_IMAGE_MB = max(1, int(os.getenv("MAX_IMAGE_MB") or "8"))
MAX_IMAGE_BYTES = MAX_IMAGE_MB * 1024 * 1024

async def _save_upload_to_path(upload: UploadFile, target: Path) -> int:
    """Stream an UploadFile to disk with a hard size limit. Returns byte size."""
    size = 0
    with target.open("wb") as f:
        while True:
            chunk = await upload.read(1024 * 1024)  # 1MB
            if not chunk:
                break
            size += len(chunk)
            if size > MAX_UPLOAD_BYTES:
                # best-effort cleanup
                try:
                    target.unlink(missing_ok=True)
                except Exception:
                    pass
                raise HTTPException(status_code=413, detail=f"File too large (max {MAX_UPLOAD_MB}MB)")
            f.write(chunk)
    return size

# lightweight in-process job runner (single-process MVP)
# NOTE: For multi-instance deployments, use a real queue (Redis + worker).
JOB_WORKERS = max(1, int(os.getenv("JOB_WORKERS") or "2"))
JOB_EXECUTOR = ThreadPoolExecutor(max_workers=JOB_WORKERS)


templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))


def _template_exists(name: str) -> bool:
    try:
        return (BASE_DIR / "templates" / name).exists()
    except Exception:
        return False


def _html_placeholder(*, title: str, message: str) -> HTMLResponse:
    msg = (message or "").replace("<", "&lt;").replace(">", "&gt;")
    html = f"""<!doctype html><html><head><meta charset='utf-8'>
    <title>{title}</title>
    <style>body{{font-family:system-ui,Segoe UI,Arial,sans-serif;padding:24px;line-height:1.45}}code{{background:#eee;padding:2px 6px;border-radius:6px}}</style>
    </head><body><h2>{title}</h2><p>{msg}</p></body></html>"""
    return HTMLResponse(html)

# static (css, js, etc.)
app.mount("/static",
          StaticFiles(directory=str(BASE_DIR / "static")),
          name="static")

# Public note images only (avoid exposing full UPLOAD_DIR)
app.mount("/uploads/images",
          StaticFiles(directory=str(IMAGE_DIR)),
          name="uploads_images")


@app.get("/favicon.ico")
def favicon():
    """Avoid noisy 404s in logs (serve favicon if present, otherwise 204)."""
    fp = BASE_DIR / "static" / "favicon.ico"
    if fp.exists():
        return FileResponse(str(fp))
    return PlainTextResponse("", status_code=204)


@app.on_event("startup")
def _startup():
    init_db()
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)
    JOB_INPUT_DIR.mkdir(parents=True, exist_ok=True)
    # best-effort cleanup of old artifacts on boot
    try:
        _cleanup_old_artifacts()
    except Exception:
        logger.exception("Artifact cleanup failed")


def _cleanup_old_artifacts(limit: int = 300) -> int:
    """Delete artifacts older than ARTIFACT_RETENTION_DAYS (DB + file) if not referenced by jobs."""
    items = list_artifacts_older_than(days=ARTIFACT_RETENTION_DAYS, limit=limit)
    deleted = 0
    for a in items:
        aid = int(a.get("id"))
        fp = ARTIFACT_DIR / (a.get("stored_name") or "")
        try:
            fp.unlink(missing_ok=True)
        except Exception:
            pass
        try:
            detach_artifact_from_jobs(aid)
            delete_artifact_row(aid)
            deleted += 1
        except Exception:
            # keep going
            continue
    return deleted


def _settings_context() -> dict:
    # so templates can use: s.answer_language, s.theme, etc.
    s = get_all_settings()
    return {"s": s}


def _unique_stored_name(label: str, ext: str) -> str:
    """Create a collision-resistant stored filename."""
    label2 = safe_filename(label or "file")
    raw = (label2 + str(os.urandom(16))).encode("utf-8", "ignore")
    h = hashlib.sha256(raw).hexdigest()[:16]
    ext2 = (ext or "").lstrip(".")
    return f"{h}_{label2}.{ext2}" if ext2 else f"{h}_{label2}"


def _pdf_tools_ctx(request: Request,
                   selected_doc_id: int | None = None,
                   message: str | None = None):
    docs = list_documents()
    artifacts = (list_artifacts_for_document(selected_doc_id, limit=40)
                 if selected_doc_id else list_artifacts(limit=40))
    ctx = {
        "request": request,
        "docs": docs,
        "selected_doc_id": selected_doc_id,
        "message": message,
        "artifacts": artifacts,
        "title": "ExamMentor – PDF eszközök",
    }
    ctx.update(_settings_context())
    return ctx


@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    ctx = {"request": request, "title": "ExamMentor – Kezdőlap"}
    ctx.update(_settings_context())
    return templates.TemplateResponse("index.html", ctx)


# ---------------- Onboarding ----------------
@app.get("/onboarding", response_class=HTMLResponse)
def onboarding_get(request: Request):
    ctx = {"request": request, "title": "ExamMentor – Onboarding"}
    ctx.update(_settings_context())
    return templates.TemplateResponse("onboarding.html", ctx)


@app.post("/onboarding")
def onboarding_post(
    request: Request,
    answer_language: str = Form("hu"),
    manual_mode: str | None = Form(None),
    translation_style: str = Form("natural"),
    default_gpt_mode: str = Form("exam"),
):
    set_setting("answer_language", (answer_language or "hu").strip())
    set_setting("manual_mode", "1" if manual_mode else "0")
    set_setting("translation_style", (translation_style or "natural").strip())
    set_setting("default_gpt_mode", (default_gpt_mode or "exam").strip())
    return RedirectResponse(url="/", status_code=303)


# ---------------- Documents ----------------
@app.get("/documents", response_class=HTMLResponse)
def documents_page(request: Request):
    docs = list_documents()
    ctx = {"request": request, "docs": docs, "title": "ExamMentor – Dokumentumok"}
    ctx.update(_settings_context())
    return templates.TemplateResponse("documents.html", ctx)


@app.post("/documents/upload")
async def documents_upload(request: Request,
                           title: str = Form(""),
                           language: str = Form("auto"),
                           pdf: UploadFile = File(...)):
    original = pdf.filename or "document.pdf"
    safe_orig = safe_filename(original, "document.pdf")

    # stored filename: hash + original
    raw = (original + str(os.urandom(8))).encode("utf-8", "ignore")
    h = hashlib.sha256(raw).hexdigest()[:24]
    stored_name = f"{h}_{safe_orig}"

    target = UPLOAD_DIR / stored_name

    try:
        size = await _save_upload_to_path(pdf, target)
    except HTTPException as e:
        if e.status_code == 413:
            ctx = {"request": request, "docs": list_documents(), "title": "ExamMentor – Dokumentumok"}
            ctx.update(_settings_context())
            ctx["message"] = f"❌ A fájl túl nagy (max {MAX_UPLOAD_MB}MB)."
            return templates.TemplateResponse("documents.html", ctx, status_code=413)
        raise

    pages = 0
    search_text = ""
    doc_type = "pdf"

    # Metadata extraction: avoid loading huge PDFs into RAM
    try:
        pages = pdf_page_count_path(target)
    except Exception:
        pages = 0

    # For very large files, limit text extraction aggressively
    try:
        if size <= 30 * 1024 * 1024:
            search_text = extract_text_from_pdf_path(target, max_pages=25)
        else:
            search_text = extract_text_from_pdf_path(target, max_pages=10)
    except Exception:
        search_text = ""

    # title fallback
    title2 = (title or "").strip() or Path(original).stem

    doc_id = insert_document(title=title2,
                             original_name=original,
                             stored_name=stored_name,
                             language=(language or "auto"),
                             pages=pages,
                             doc_type=doc_type,
                             search_text=search_text)

    return RedirectResponse(url=f"/documents/{doc_id}", status_code=303)


@app.get("/documents/{doc_id}", response_class=HTMLResponse)
def document_detail(request: Request, doc_id: int):
    doc = get_document(doc_id)
    if not doc:
        ctx = {
            "request": request,
            "message": "Document not found",
            "title": "ExamMentor – Nem található",
        }
        ctx.update(_settings_context())
        return templates.TemplateResponse("not_found.html",
                                          ctx,
                                          status_code=404)

    # This URL serves the PDF bytes in-browser:
    file_url = f"/documents/{doc_id}/file"

    doc_title = (doc.get("title") or "Dokumentum").strip() or "Dokumentum"
    ctx = {
        "request": request,
        "doc": doc,
        "file_url": file_url,
        "title": f"ExamMentor – {doc_title}",
    }
    ctx.update(_settings_context())
    return templates.TemplateResponse("document_detail.html", ctx)


@app.get("/documents/{doc_id}/file")
def document_file(doc_id: int):
    doc = get_document(doc_id)
    if not doc:
        return PlainTextResponse("Not found", status_code=404)

    stored_name = doc.get("stored_name") or ""
    fp = UPLOAD_DIR / stored_name
    if not fp.exists():
        return PlainTextResponse("File missing", status_code=404)

    # IMPORTANT: inline -> open in browser (not forced download)
    return FileResponse(
        str(fp),
        media_type="application/pdf",
        filename=doc.get("original_name", "document.pdf"),
        headers={
            "Content-Disposition":
            f'inline; filename="{doc.get("original_name","document.pdf")}"'
        })


@app.get("/documents/{doc_id}/download")
def document_download(doc_id: int):
    """Force-download the original uploaded document."""
    doc = get_document(doc_id)
    if not doc:
        return PlainTextResponse("Not found", status_code=404)

    fp = UPLOAD_DIR / (doc.get("stored_name") or "")
    if not fp.exists():
        return PlainTextResponse("File missing", status_code=404)

    return FileResponse(
        str(fp),
        media_type="application/pdf",
        filename=doc.get("original_name", "document.pdf"),
        headers={
            "Content-Disposition":
            f'attachment; filename="{doc.get("original_name","document.pdf")}"'
        },
    )


@app.get("/artifacts/{artifact_id}/download")
def artifact_download(artifact_id: int):
    """Download a generated artifact (exports, ZIPs, etc.)."""
    a = get_artifact(artifact_id)
    if not a:
        return PlainTextResponse("Not found", status_code=404)

    fp = ARTIFACT_DIR / (a.get("stored_name") or "")
    if not fp.exists():
        return PlainTextResponse("File missing", status_code=404)

    mime = a.get("mime_type") or "application/octet-stream"
    fname = a.get("original_name") or (fp.name)
    return FileResponse(
        str(fp),
        media_type=mime,
        filename=fname,
        headers={"Content-Disposition": f'attachment; filename="{fname}"'},
    )


# ---------------- Uploads (note images) ----------------
@app.post("/api/uploads/image")
async def upload_note_image(image: UploadFile = File(...)):
    """Upload an image for notes and return a safe URL.

    - Validates content type
    - Enforces size limits
    - Decodes with Pillow and re-encodes to PNG/JPEG (strips metadata)

    This endpoint is intentionally dependency-light:
    - If Pillow isn't installed, it returns a clear error (route still exists).
    """
    ct = (image.content_type or "").lower().strip()
    if not ct.startswith("image/") or ct == "image/svg+xml":
        return JSONResponse({"ok": False, "error": "unsupported_type"}, status_code=400)

    data = await image.read()
    if not data:
        return JSONResponse({"ok": False, "error": "empty"}, status_code=400)
    if len(data) > MAX_IMAGE_BYTES:
        return JSONResponse({"ok": False, "error": "too_large", "max_mb": MAX_IMAGE_MB}, status_code=413)

    try:
        from PIL import Image as PILImage  # type: ignore
    except Exception:
        return JSONResponse({"ok": False, "error": "pillow_missing"}, status_code=500)

    try:
        bio = io.BytesIO(data)
        img = PILImage.open(bio)
        img.load()
        w, h = img.size
        if w <= 0 or h <= 0 or (w * h) > 20_000_000:
            return JSONResponse({"ok": False, "error": "bad_dimensions"}, status_code=400)

        # Downscale huge images (best-effort)
        max_px = 2000
        scale = min(1.0, float(max_px) / float(w), float(max_px) / float(h))
        if scale < 1.0:
            nw = max(1, int(w * scale))
            nh = max(1, int(h * scale))
            img = img.resize((nw, nh), getattr(PILImage, "LANCZOS", 1))

        # Choose a stable output format
        bands = tuple(img.getbands() or ())
        has_alpha = ("A" in bands)
        out = io.BytesIO()

        if has_alpha:
            if img.mode != "RGBA":
                img = img.convert("RGBA")
            img.save(out, format="PNG", optimize=True)
            ext = "png"
        else:
            if img.mode != "RGB":
                img = img.convert("RGB")
            img.save(out, format="JPEG", quality=85, optimize=True)
            ext = "jpg"

        out_bytes = out.getvalue()
        if not out_bytes:
            return JSONResponse({"ok": False, "error": "encode_failed"}, status_code=400)

    except Exception:
        return JSONResponse({"ok": False, "error": "invalid_image"}, status_code=400)

    fname = f"{uuid.uuid4().hex}.{ext}"
    fp = IMAGE_DIR / fname
    fp.write_bytes(out_bytes)

    return {
        "ok": True,
        "url": f"/uploads/images/{fname}",
        "filename": fname,
        "bytes": len(out_bytes),
    }


# ---------------- Translation (route block) ----------------
@app.get("/documents/{doc_id}/translate", response_class=HTMLResponse)
def document_translate_page(request: Request, doc_id: int):
    """UI entrypoint for translation.

    Phase 1A: route exists and is non-crashing.
    Phase 1B: translator pipeline will be plugged in.
    """
    title = "ExamMentor – Fordítás"
    if not _template_exists("document_translate.html"):
        return _html_placeholder(title=title,
                                 message="🚧 Translation modul UI még nincs bemásolva (document_translate.html hiányzik).")
    doc = get_document(doc_id)
    if not doc:
        return templates.TemplateResponse("not_found.html",
                                          {"request": request, "message": "Document not found", "title": title},
                                          status_code=404)
    ctx = {"request": request, "doc": doc, "title": title, "message": "🚧 Translation backend Phase 1B-ben kerül bekötésre."}
    ctx.update(_settings_context())
    return templates.TemplateResponse("document_translate.html", ctx)


@app.get("/documents/{doc_id}/translate/export")
def document_translate_export(doc_id: int, format: str = "txt"):
    # Placeholder export route (Phase 1B wires actual export).
    return PlainTextResponse("Translation export is not enabled yet (Phase 1B).", status_code=501)


@app.post("/documents/{doc_id}/translate/save")
def document_translate_save(doc_id: int, text: str = Form("")):
    return RedirectResponse(url=f"/documents/{doc_id}/translate", status_code=303)


# ---------------- PPT Generator (route block) ----------------
@app.get("/ppt-generator", response_class=HTMLResponse)
def ppt_generator_page(request: Request):
    title = "ExamMentor – PPT generálás"
    if not _template_exists("ppt_generator.html"):
        return _html_placeholder(title=title,
                                 message="🚧 PPT modul UI még nincs bemásolva (ppt_generator.html hiányzik).")
    ctx = {"request": request, "title": title, "message": "🚧 PPT backend Phase 1B-ben kerül bekötésre."}
    ctx.update(_settings_context())
    return templates.TemplateResponse("ppt_generator.html", ctx)


@app.get("/ppt-jobs", response_class=HTMLResponse)
def ppt_jobs_page(request: Request):
    title = "ExamMentor – PPT jobok"
    if not _template_exists("ppt_jobs.html"):
        return _html_placeholder(title=title,
                                 message="🚧 PPT jobs UI még nincs bemásolva (ppt_jobs.html hiányzik).")
    ctx = {"request": request, "title": title, "jobs": [], "message": "🚧 Phase 1B"}
    ctx.update(_settings_context())
    return templates.TemplateResponse("ppt_jobs.html", ctx)


# ---------------- Speech-to-text (route block) ----------------
@app.get("/speech-to-text", response_class=HTMLResponse)
def speech_to_text_page(request: Request):
    title = "ExamMentor – Hang → szöveg"
    if not _template_exists("speech_to_text.html"):
        return _html_placeholder(title=title,
                                 message="🚧 Speech modul UI még nincs bemásolva (speech_to_text.html hiányzik).")
    ctx = {"request": request, "title": title, "jobs": [], "message": "🚧 Speech backend Phase 1B-ben kerül bekötésre."}
    ctx.update(_settings_context())
    return templates.TemplateResponse("speech_to_text.html", ctx)


# ---------------- OCR Jobs (route block / stub) ----------------
@app.get("/ocr-jobs", response_class=HTMLResponse)
def ocr_jobs_dashboard(request: Request):
    title = "ExamMentor – OCR jobok"
    if not _template_exists("ocr_jobs.html"):
        return _html_placeholder(title=title,
                                 message="🚧 OCR jobs UI még nincs bemásolva (ocr_jobs.html hiányzik).")
    ctx = {"request": request, "title": title, "rows": [], "message": "🚧 OCR backend Phase 1B-ben kerül bekötésre."}
    ctx.update(_settings_context())
    return templates.TemplateResponse("ocr_jobs.html", ctx)



# ---------------- Notes ----------------
@app.get("/notes", response_class=HTMLResponse)
def notes_page(request: Request):
    notes = list_notes()
    ctx = {
        "request": request,
        "notes": notes,
        "docs": list_documents(),
        "title": "ExamMentor – Jegyzetek",
    }
    ctx.update(_settings_context())
    return templates.TemplateResponse("notes.html", ctx)


@app.get("/notes/new", response_class=HTMLResponse)
def note_new_page(request: Request):
    # Template expects a `note` object. When creating a new note, pass a safe default
    # so Jinja doesn't raise UndefinedError.
    pre_doc = None
    qp_doc = (request.query_params.get("doc") or "").strip()
    if qp_doc:
        try:
            pre_doc = int(qp_doc)
        except Exception:
            pre_doc = None

    note = {
        "id": 0,
        "title": "",
        "body": "",
        "document_id": pre_doc,
    }
    ctx = {
        "request": request,
        "docs": list_documents(),
        "note": note,
        "mode": "new",
        "title": "ExamMentor – Új jegyzet",
    }
    ctx.update(_settings_context())
    return templates.TemplateResponse("note_edit.html", ctx)


@app.post("/notes/new")
def note_new_post(request: Request,
                  title: str = Form(""),
                  body: str = Form(""),
                  document_id: str = Form("")):
    title2 = (title or "").strip() or "Untitled"
    body2 = (body or "").strip()
    doc_id_val = None
    if (document_id or "").strip():
        try:
            doc_id_val = int(document_id)
        except Exception:
            doc_id_val = None

    nid = insert_note(title2, body2, doc_id_val)
    return RedirectResponse(url=f"/notes/{nid}", status_code=303)


@app.get("/notes/{note_id}", response_class=HTMLResponse)
def note_detail(request: Request, note_id: int):
    note = get_note(note_id)
    if not note:
        ctx = {
            "request": request,
            "message": "Note not found",
            "title": "ExamMentor – Nem található",
        }
        ctx.update(_settings_context())
        return templates.TemplateResponse("not_found.html",
                                          ctx,
                                          status_code=404)

    note_title = (note.get("title") or "Jegyzet").strip() or "Jegyzet"
    ctx = {"request": request, "note": note, "title": f"ExamMentor – {note_title}"}
    ctx.update(_settings_context())
    return templates.TemplateResponse("note_detail.html", ctx)


@app.get("/notes/{note_id}/edit", response_class=HTMLResponse)
def note_edit_page(request: Request, note_id: int):
    note = get_note(note_id)
    if not note:
        ctx = {
            "request": request,
            "message": "Note not found",
            "title": "ExamMentor – Nem található",
        }
        ctx.update(_settings_context())
        return templates.TemplateResponse("not_found.html",
                                          ctx,
                                          status_code=404)

    ctx = {
        "request": request,
        "note": note,
        "docs": list_documents(),
        "mode": "edit",
        "title": "ExamMentor – Jegyzet szerkesztése",
    }
    ctx.update(_settings_context())
    return templates.TemplateResponse("note_edit.html", ctx)


@app.post("/notes/{note_id}/edit")
def note_edit_post(request: Request,
                   note_id: int,
                   title: str = Form(""),
                   body: str = Form(""),
                   document_id: str = Form("")):
    doc_id_val = None
    if (document_id or "").strip():
        try:
            doc_id_val = int(document_id)
        except Exception:
            doc_id_val = None

    update_note(note_id, (title or "").strip() or "Untitled",
                (body or "").strip(), doc_id_val)
    return RedirectResponse(url=f"/notes/{note_id}", status_code=303)


# --- Notes v2 (rich editor helpers / stubs in Phase 1A) ---
@app.get("/notes/{note_id}/history", response_class=HTMLResponse)
def note_history_page(request: Request, note_id: int):
    title = "ExamMentor – Verziótörténet"
    if not _template_exists("note_history.html"):
        return _html_placeholder(title=title,
                                 message="🚧 note_history.html hiányzik (Phase 1B-ben kerül bemásolásra).")
    ctx = {"request": request, "title": title, "note_id": note_id, "versions": []}
    ctx.update(_settings_context())
    return templates.TemplateResponse("note_history.html", ctx)


@app.get("/notes/{note_id}/versions/{version_id}", response_class=HTMLResponse)
def note_version_view_page(request: Request, note_id: int, version_id: int):
    title = "ExamMentor – Verzió nézet"
    if not _template_exists("note_version_view.html"):
        return _html_placeholder(title=title,
                                 message="🚧 note_version_view.html hiányzik (Phase 1B-ben kerül bemásolásra).")
    ctx = {"request": request, "title": title, "note_id": note_id, "version_id": version_id, "version": None}
    ctx.update(_settings_context())
    return templates.TemplateResponse("note_version_view.html", ctx)


@app.get("/api/notes/{note_id}/versions")
def api_note_versions(note_id: int):
    if hasattr(db_mod, "list_note_versions"):
        return {"ok": True, "versions": db_mod.list_note_versions(int(note_id))}  # type: ignore[attr-defined]
    return JSONResponse({"ok": False, "error": "not_enabled"}, status_code=501)


@app.post("/api/notes/{note_id}/restore")
def api_note_restore(note_id: int, version_id: int = Form(...)):
    if hasattr(db_mod, "restore_note_version"):
        db_mod.restore_note_version(int(note_id), int(version_id))  # type: ignore[attr-defined]
        return {"ok": True}
    return JSONResponse({"ok": False, "error": "not_enabled"}, status_code=501)


@app.post("/api/notes/{note_id}/autosave")
def api_note_autosave(note_id: int, body: str = Form(""), body_format: str = Form("html")):
    if hasattr(db_mod, "autosave_note"):
        res = db_mod.autosave_note(int(note_id), body, body_format=body_format)  # type: ignore[attr-defined]
        return {"ok": True, "result": res}
    return JSONResponse({"ok": False, "error": "not_enabled"}, status_code=501)


@app.get("/api/notes/{note_id}/meta")
def api_note_meta(note_id: int):
    if hasattr(db_mod, "get_note_meta"):
        return {"ok": True, "meta": db_mod.get_note_meta(int(note_id))}  # type: ignore[attr-defined]
    return JSONResponse({"ok": False, "error": "not_enabled"}, status_code=501)


@app.post("/api/notes/draft")
def api_note_draft(title: str = Form(""), body: str = Form(""), document_id: str = Form(""), body_format: str = Form("html")):
    if hasattr(db_mod, "insert_note_v2"):
        doc_id_val = None
        if (document_id or "").strip():
            try:
                doc_id_val = int(document_id)
            except Exception:
                doc_id_val = None
        nid = db_mod.insert_note_v2((title or "").strip() or "Untitled", body or "", doc_id_val, body_format=body_format)  # type: ignore[attr-defined]
        return {"ok": True, "note_id": int(nid)}
    return JSONResponse({"ok": False, "error": "not_enabled"}, status_code=501)


@app.get("/api/notes/{note_id}/export/markdown", response_class=PlainTextResponse)
def api_note_export_markdown(note_id: int):
    if hasattr(db_mod, "export_note_markdown"):
        md = db_mod.export_note_markdown(int(note_id))  # type: ignore[attr-defined]
        return PlainTextResponse(md or "", media_type="text/plain; charset=utf-8")
    return PlainTextResponse("Not enabled", status_code=501)


# ---------------- Ask ----------------
@app.get("/ask", response_class=HTMLResponse)
def ask_get(request: Request, q: str = "", scope: str = "all", doc: str = ""):
    docs_list = list_documents()

    doc_id_val = None
    if (doc or "").strip():
        try:
            doc_id_val = int(doc)
        except Exception:
            doc_id_val = None

    q2 = (q or "").strip()
    results_notes = []
    results_docs = []
    answer_lines = []

    if q2:
        if scope in ("all", "notes"):
            results_notes = search_notes(q=q2,
                                         document_id=doc_id_val,
                                         limit=12)
        if scope in ("all", "docs"):
            results_docs = search_documents(q=q2, limit=8)

        for n in results_notes[:6]:
            snippet = make_snippet(n.get("body", ""), q2)
            answer_lines.append(f"📝 {n.get('title','')} — {snippet}")

        for d in results_docs[:4]:
            snippet = make_snippet(d.get("search_text", ""), q2)
            answer_lines.append(f"📄 {d.get('title','')} — {snippet}")

    compiled_answer = "\n".join(answer_lines).strip()

    ctx = {
        "request": request,
        "title": "ExamMentor – Keresés",
        "q": q2,
        "scope": scope,
        "docs": docs_list,
        "doc_selected": doc_id_val,
        "results_notes": results_notes,
        "results_docs": results_docs,
        "compiled_answer": compiled_answer,
    }
    ctx.update(_settings_context())
    return templates.TemplateResponse("ask.html", ctx)


@app.post("/ask")
def ask_post(request: Request,
             q: str = Form(""),
             scope: str = Form("all"),
             doc: str = Form("")):
    q_enc = quote_plus((q or "").strip())
    scope_enc = quote_plus((scope or "all").strip())
    doc_enc = quote_plus((doc or "").strip())
    return RedirectResponse(
        url=f"/ask?q={q_enc}&scope={scope_enc}&doc={doc_enc}", status_code=303)


# ---------------- Study / Quiz (integrated route block) ----------------
def _study_backend_ready() -> bool:
    """Study/quiz depends on extra DB helpers + ai_tutor/quiz_session.

    Phase-1 A goal: routes exist and the app boots. If backend isn't ready yet,
    handlers will render a clear placeholder instead of crashing.
    """
    required = [
        "get_user_progress",
        "count_due_cards",
        "create_quiz_session",
        "get_quiz_session",
        "record_quiz_attempt",
        "list_attempts_for_session",
        "get_quiz_attempt",
        "list_recent_attempts",
        "list_due_card_json",
    ]
    return all(hasattr(db_mod, n) for n in required)


@app.get("/study", response_class=HTMLResponse)
def study_home(request: Request):
    title = "ExamMentor – Study"
    docs = list_documents()
    msg = (request.query_params.get("msg") or "").strip()

    total = correct = points = due = 0
    if _study_backend_ready():
        try:
            p = db_mod.get_user_progress()  # type: ignore[attr-defined]
            total = int(p.get("total_attempts") or 0)
            correct = int(p.get("correct_attempts") or 0)
            points = int(p.get("points") or 0)
            due = int(db_mod.count_due_cards() or 0)  # type: ignore[attr-defined]
        except Exception:
            msg = msg or "backend_error"

    if not _template_exists("study.html"):
        return _html_placeholder(title=title,
                                 message="Study UI template missing (study.html).")

    ctx = {
        "request": request,
        "docs": docs,
        "total": total,
        "due": due,
        "correct": correct,
        "points": points,
        "msg": msg,
        "title": title,
    }
    ctx.update(_settings_context())
    if not _study_backend_ready():
        ctx["message"] = "🚧 Study/Quiz backend még nincs bedrótozva (Phase 1B). A route-ok már léteznek."
    return templates.TemplateResponse("study.html", ctx)


@app.post("/study/generate")
def study_generate(doc: str = Form(""), difficulty: str = Form("medium"), n: int = Form(10)):
    """UI compatibility endpoint.

    Some study UIs POST to /study/generate. In Phase-1 we keep this route present
    and redirect to the quiz entrypoint, or to a clear 'not enabled' message.
    """
    if not _study_backend_ready():
        return RedirectResponse(url="/study?msg=not_enabled", status_code=303)
    q = ""
    if (doc or "").strip():
        q += f"doc={quote_plus((doc or '').strip())}&"
    q += f"difficulty={quote_plus((difficulty or 'medium').strip())}&n={int(n or 10)}"
    return RedirectResponse(url=f"/study/quiz?{q}", status_code=303)


@app.get("/study/cards")
def study_cards():
    """Legacy alias used by older UIs.

    Phase 1: keep route present to avoid 404s.
    """
    return RedirectResponse(url="/study?msg=cards_coming_soon", status_code=303)


@app.get("/study/session")
def study_session():
    """Legacy alias used by older UIs."""
    return RedirectResponse(url="/study?msg=session_coming_soon", status_code=303)


@app.get("/study/stats")
def study_stats():
    """Legacy alias used by older UIs."""
    return RedirectResponse(url="/study/progress", status_code=303)


@app.get("/study/progress", response_class=HTMLResponse)
def study_progress(request: Request):
    title = "ExamMentor – Study Progress"
    if not _study_backend_ready():
        return _html_placeholder(title=title,
                                 message="🚧 Study progress backend még nincs kész (Phase 1B).")
    if not _template_exists("study_progress.html"):
        return _html_placeholder(title=title,
                                 message="study_progress.html template missing.")
    try:
        p = db_mod.get_user_progress()  # type: ignore[attr-defined]
        total = int(p.get("total_attempts") or 0)
        correct = int(p.get("correct_attempts") or 0)
        points = int(p.get("points") or 0)
        attempts = db_mod.list_recent_attempts(limit=50)  # type: ignore[attr-defined]
        rate = (100.0 * correct / total) if total else 0.0
    except Exception:
        return _html_placeholder(title=title, message="Internal error loading progress.")

    ctx = {
        "request": request,
        "total": total,
        "correct": correct,
        "wrong": max(0, total - correct),
        "points": points,
        "rate": f"{rate:.1f}",
        "attempts": attempts,
        "docs": list_documents(),
        "title": title,
    }
    ctx.update(_settings_context())
    return templates.TemplateResponse("study_progress.html", ctx)


@app.get("/study/review")
def study_review(n: int = 12):
    if not _study_backend_ready():
        return RedirectResponse(url="/study?msg=not_enabled", status_code=303)
    # Full review flow is wired in Phase 1B (needs ai_tutor + card bank).
    return RedirectResponse(url="/study?msg=review_coming_soon", status_code=303)


@app.get("/study/quiz", response_class=HTMLResponse)
def study_quiz(request: Request, doc: str = "", difficulty: str = "medium", n: int = 10, session: str = "", i: int = 0):
    title = "ExamMentor – Quiz"
    if not _study_backend_ready():
        return _html_placeholder(title=title,
                                 message="🚧 Quiz backend még nincs kész (Phase 1B).")
    # Phase 1A: route exists. Phase 1B will plug in QuizQuality_v4 session builder.
    return _html_placeholder(title=title,
                             message="Quiz route elérhető, de a QuizQuality engine Phase 1B-ben kerül bekötésre.")


@app.post("/study/quiz/answer")
def study_quiz_answer(request: Request,
                      session_id: int = Form(...),
                      i: int = Form(...),
                      picked: str = Form(""),
                      doc: str = Form(""),
                      difficulty: str = Form("medium"),
                      n: int = Form(10)):
    if not _study_backend_ready():
        return RedirectResponse(url="/study?msg=not_enabled", status_code=303)
    return RedirectResponse(url="/study?msg=quiz_coming_soon", status_code=303)


@app.get("/study/quiz/adaptive")
def study_quiz_adaptive(session: int, n: int = 8):
    if not _study_backend_ready():
        return RedirectResponse(url="/study?msg=not_enabled", status_code=303)
    return RedirectResponse(url="/study?msg=adaptive_coming_soon", status_code=303)


# ---------------- Settings ----------------
@app.get("/settings", response_class=HTMLResponse)
def settings_page(request: Request):
    s = get_all_settings()
    ctx = {
        "request": request,
        "settings": s,
        "title": "ExamMentor – Beállítások",
    }
    ctx.update(_settings_context())
    return templates.TemplateResponse("settings.html", ctx)


@app.post("/settings")
def settings_save(
        request: Request,
        ui_lang: str = Form("hu"),
        answer_language: str = Form("hu"),
        theme: str = Form("dark"),
):
    set_setting("ui_lang", (ui_lang or "hu").strip())
    set_setting("answer_language", (answer_language or "hu").strip())
    set_setting("theme", (theme or "dark").strip())
    return RedirectResponse(url="/settings", status_code=303)


# ---------------- PDF Tools (exports + stable downloads) ----------------
@app.get("/pdf-tools", response_class=HTMLResponse)
def pdf_tools_page(request: Request, doc_id: int | None = None):
    return templates.TemplateResponse("pdf_tools.html",
                                      _pdf_tools_ctx(request,
                                                    selected_doc_id=doc_id))



def _get_doc_pdf_path(doc_id: int) -> tuple[dict, Path] | None:
    doc = get_document(doc_id)
    if not doc:
        return None
    fp = UPLOAD_DIR / (doc.get("stored_name") or "")
    if not fp.exists():
        return None
    return doc, fp


def _load_doc_pdf_bytes(doc_id: int) -> tuple[dict, bytes] | None:
    loaded = _get_doc_pdf_path(doc_id)
    if not loaded:
        return None
    doc, fp = loaded
    return doc, fp.read_bytes()


# ---------------- API v1 (for cross-platform clients) ----------------

def _api_document_payload(doc: dict) -> dict:
    doc_id = int(doc.get("id"))
    return {
        "id": doc_id,
        "title": doc.get("title") or "",
        "original_name": doc.get("original_name") or "",
        "language": doc.get("language") or "auto",
        "pages": int(doc.get("pages") or 0),
        "doc_type": doc.get("doc_type") or "pdf",
        "created_at": doc.get("created_at") or "",
        "file_url": f"/documents/{doc_id}/file",
        "download_url": f"/documents/{doc_id}/download",
    }


def _api_artifact_payload(a: dict) -> dict:
    aid = int(a.get("id"))
    return {
        "id": aid,
        "kind": a.get("kind") or "",
        "document_id": a.get("document_id"),
        "original_name": a.get("original_name") or "",
        "mime_type": a.get("mime_type") or "application/octet-stream",
        "size_bytes": int(a.get("size_bytes") or 0),
        "created_at": a.get("created_at") or "",
        "download_url": f"/artifacts/{aid}/download",
    }


def _create_artifact_from_bytes(*,
                               kind: str,
                               document_id: int | None,
                               original_name: str,
                               mime_type: str,
                               data: bytes) -> dict:
    """Create artifact file + DB row and return the DB row (dict)."""
    stem = safe_filename(Path(original_name).stem, "artifact")
    ext = (Path(original_name).suffix or "").lstrip(".")
    stored = _unique_stored_name(stem, ext)
    (ARTIFACT_DIR / stored).write_bytes(data)
    aid = insert_artifact(
        kind=kind,
        document_id=document_id,
        original_name=original_name,
        stored_name=stored,
        mime_type=mime_type,
        size_bytes=len(data),
    )
    a = get_artifact(aid) or {
        "id": aid,
        "kind": kind,
        "document_id": document_id,
        "original_name": original_name,
        "stored_name": stored,
        "mime_type": mime_type,
        "size_bytes": len(data),
        "created_at": "",
    }
    return a




def _api_job_payload(j: dict) -> dict:
    jid = int(j.get("id"))
    artifact_id = j.get("artifact_id")
    artifact_id = int(artifact_id) if artifact_id is not None else None
    return {
        "id": jid,
        "kind": j.get("kind") or "",
        "status": j.get("status") or "queued",
        "document_id": int(j.get("document_id")) if j.get("document_id") is not None else None,
        "artifact_id": artifact_id,
        "error": j.get("error"),
        "params_json": j.get("params_json") or "{}",
        "created_at": j.get("created_at"),
        "started_at": j.get("started_at"),
        "finished_at": j.get("finished_at"),
        "download_url": f"/artifacts/{artifact_id}/download" if artifact_id else None,
    }


async def _store_job_input(upload: UploadFile) -> str:
    """Store a job input file on disk and return the stored filename."""
    stem = safe_filename(Path(upload.filename or "input").stem, "input")
    ext = (Path(upload.filename or "").suffix or ".bin").lstrip(".")
    stored = f"jobin_{stem}_{uuid.uuid4().hex}.{ext}"
    target = JOB_INPUT_DIR / stored
    await _save_upload_to_path(upload, target)
    return stored


def _enqueue_job(kind: str, document_id: int | None, params: dict) -> dict:
    jid = insert_job(kind=kind, document_id=document_id, params_json=json.dumps(params or {}))
    # fire-and-forget dispatch (thread or Redis queue)
    submit_job(int(jid), executor=JOB_EXECUTOR, job_func=_run_job)
    j = get_job(jid) or {"id": jid, "kind": kind, "status": "queued", "document_id": document_id, "params_json": json.dumps(params or {})}
    return _api_job_payload(j)


def _run_job(job_id: int) -> None:
    j = get_job(job_id)
    if not j:
        return
    started = datetime.utcnow().isoformat()
    update_job(job_id, status="running", started_at=started)
    try:
        kind = (j.get("kind") or "").strip()
        params = {}
        try:
            params = json.loads(j.get("params_json") or "{}") or {}
        except Exception:
            params = {}

        doc_id = int(j.get("document_id")) if j.get("document_id") is not None else None
        artifact = None

        if kind == "pdf_compress":
            if doc_id is None:
                raise ValueError("Missing document_id")
            loaded = _load_doc_pdf_bytes(doc_id)
            if not loaded:
                raise FileNotFoundError("Document not found or file missing")
            doc, data = loaded
            out = compress_pdf_bytes(data)
            base = safe_filename(Path(doc.get("original_name", "document.pdf")).stem, "document")
            original_out = f"{base}_compressed.pdf"
            artifact = _create_artifact_from_bytes(
                kind="pdf_compress",
                document_id=doc_id,
                original_name=original_out,
                mime_type="application/pdf",
                data=out,
            )

        elif kind == "pdf_split":
            if doc_id is None:
                raise ValueError("Missing document_id")
            loaded = _load_doc_pdf_bytes(doc_id)
            if not loaded:
                raise FileNotFoundError("Document not found or file missing")
            doc, data = loaded
            ranges_text = (params.get("ranges_text") or "").strip()
            ranges = parse_ranges(ranges_text)
            parts = split_pdf_bytes(data, ranges)
            base = safe_filename(Path(doc.get("original_name", "document.pdf")).stem, "document")
            zip_bytes = zip_files_bytes(parts, root_folder=f"{base}_split")
            original_out = f"{base}_split.zip"
            artifact = _create_artifact_from_bytes(
                kind="pdf_split_zip",
                document_id=doc_id,
                original_name=original_out,
                mime_type="application/zip",
                data=zip_bytes,
            )


        elif kind == "pdf_extract_text":
            if doc_id is None:
                raise ValueError("Missing document_id")
            loaded = _load_doc_pdf_bytes(doc_id)
            if not loaded:
                raise FileNotFoundError("Document not found or file missing")
            doc, data = loaded
            max_pages = int(params.get("max_pages") or 25)
            text = extract_text_from_pdf(data, max_pages=max(1, min(max_pages, 200)))
            base = safe_filename(Path(doc.get("original_name", "document.pdf")).stem, "document")
            original_out = f"{base}_text.txt"
            artifact = _create_artifact_from_bytes(
                kind="pdf_text",
                document_id=doc_id,
                original_name=original_out,
                mime_type="text/plain; charset=utf-8",
                data=text.encode("utf-8"),
            )

        elif kind == "pdf_to_images":
            if doc_id is None:
                raise ValueError("Missing document_id")
            loaded = _load_doc_pdf_bytes(doc_id)
            if not loaded:
                raise FileNotFoundError("Document not found or file missing")
            doc, data = loaded
            ranges_text = (params.get("ranges_text") or "").strip()
            dpi = int(params.get("dpi") or 150)
            image_format = (params.get("image_format") or "png").lower().strip()
            ranges = parse_ranges(ranges_text) if ranges_text else None
            out = pdf_to_images_zip_bytes(data, ranges=ranges, dpi=max(72, min(dpi, 300)), image_format=image_format)
            base = safe_filename(Path(doc.get("original_name", "document.pdf")).stem, "document")
            original_out = f"{base}_images.zip"
            artifact = _create_artifact_from_bytes(
                kind="pdf_images_zip",
                document_id=doc_id,
                original_name=original_out,
                mime_type="application/zip",
                data=out,
            )

        elif kind == "images_to_pdf":
            image_files = params.get("image_files") or []
            if not isinstance(image_files, list) or not image_files:
                raise ValueError("No images provided")
            images: list[bytes] = []
            for fname in image_files:
                fp = JOB_INPUT_DIR / str(fname)
                if not fp.exists():
                    continue
                images.append(fp.read_bytes())
            if not images:
                raise ValueError("No readable images found")
            out = images_to_pdf_bytes(images)
            output_name = safe_filename(params.get("output_name") or "images", "images")
            original_out = f"{output_name}.pdf"
            artifact = _create_artifact_from_bytes(
                kind="images_to_pdf",
                document_id=None,
                original_name=original_out,
                mime_type="application/pdf",
                data=out,
            )
            # cleanup inputs best-effort
            for fname in image_files:
                try:
                    (JOB_INPUT_DIR / str(fname)).unlink(missing_ok=True)
                except Exception:
                    pass

        else:
            raise ValueError(f"Unknown job kind: {kind}")

        if not artifact:
            raise RuntimeError("Job did not produce artifact")

        finished = datetime.utcnow().isoformat()
        update_job(job_id, status="succeeded", artifact_id=int(artifact["id"]), finished_at=finished)
    except Exception as e:
        logger.exception("Job %s failed", job_id)
        finished = datetime.utcnow().isoformat()
        update_job(job_id, status="failed", error=str(e), finished_at=finished)

@app.get("/api/v1/health")
def api_health():
    return {"ok": True}


@app.get("/health")
def health_legacy():
    """Legacy health endpoint (alias)."""
    return api_health()



@app.get("/api/v1/jobs")
def api_list_jobs(limit: int = 100):
    items = list_jobs(limit=limit)
    return {"ok": True, "items": [_api_job_payload(j) for j in items]}


@app.get("/api/v1/jobs/{job_id}")
def api_get_job(job_id: int):
    j = get_job(int(job_id))
    if not j:
        raise HTTPException(status_code=404, detail="Job not found")
    payload = _api_job_payload(j)
    if payload.get("artifact_id"):
        a = get_artifact(int(payload["artifact_id"]))
        if a:
            payload["artifact"] = _api_artifact_payload(a)
    return {"ok": True, "item": payload}


@app.get("/api/v1/jobs/{job_id}/download")
def api_job_download(job_id: int):
    j = get_job(int(job_id))
    if not j:
        raise HTTPException(status_code=404, detail="Job not found")
    if (j.get("status") or "") != "succeeded" or not j.get("artifact_id"):
        raise HTTPException(status_code=409, detail="Job not finished")
    return RedirectResponse(url=f"/artifacts/{int(j['artifact_id'])}/download", status_code=302)

@app.get("/api/v1/documents")
def api_list_documents(limit: int = 100):
    docs = list_documents()[:max(1, min(int(limit or 100), 200))]
    return {"ok": True, "items": [_api_document_payload(d) for d in docs]}


@app.get("/api/v1/documents/{doc_id}")
def api_get_document(doc_id: int):
    doc = get_document(doc_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    return {"ok": True, "item": _api_document_payload(doc)}


@app.post("/api/v1/documents")
async def api_upload_document(
    title: str = Form(""),
    language: str = Form("auto"),
    pdf: UploadFile = File(...),
):
    original = pdf.filename or "document.pdf"
    safe_orig = safe_filename(original, "document.pdf")

    # stored filename: hash + original
    raw = (original + str(os.urandom(8))).encode("utf-8", "ignore")
    h = hashlib.sha256(raw).hexdigest()[:24]
    stored_name = f"{h}_{safe_orig}"

    target = UPLOAD_DIR / stored_name

    try:
        size = await _save_upload_to_path(pdf, target)
    except HTTPException as e:
        raise e

    pages = 0
    search_text = ""
    doc_type = "pdf"

    # metadata extraction (path-based for large files)
    try:
        pages = pdf_page_count_path(target)
    except Exception:
        pages = 0

    try:
        if size <= 30 * 1024 * 1024:
            search_text = extract_text_from_pdf_path(target, max_pages=25)
        else:
            # keep this light for huge PDFs
            search_text = extract_text_from_pdf_path(target, max_pages=10)
    except Exception:
        search_text = ""

    title2 = (title or "").strip() or Path(original).stem

    doc_id = insert_document(
        title=title2,
        original_name=original,
        stored_name=stored_name,
        language=(language or "auto"),
        pages=pages,
        doc_type=doc_type,
        search_text=search_text,
    )

    doc = get_document(int(doc_id))
    return {"ok": True, "item": _api_document_payload(doc) if doc else {"id": doc_id}}


@app.get("/api/v1/artifacts")
def api_list_artifacts(limit: int = 100, document_id: int | None = None):
    lim = max(1, min(int(limit or 100), 200))
    if document_id is None:
        items = list_artifacts(limit=lim)
    else:
        items = list_artifacts_for_document(int(document_id), limit=lim)
    return {"ok": True, "items": [_api_artifact_payload(a) for a in items]}


@app.get("/api/v1/artifacts/{artifact_id}")
def api_get_artifact(artifact_id: int):
    a = get_artifact(artifact_id)
    if not a:
        raise HTTPException(status_code=404, detail="Artifact not found")
    return {"ok": True, "item": _api_artifact_payload(a)}




@app.get("/api/v1/artifacts/{artifact_id}/download")
def api_download_artifact(artifact_id: int):
    # same as HTML route, but namespaced for API clients
    return artifact_download(artifact_id=int(artifact_id))


@app.get("/api/v1/documents/{doc_id}/download")
def api_download_document(doc_id: int):
    return document_download(doc_id=int(doc_id))


@app.post("/api/v1/maintenance/cleanup")
def api_cleanup(limit: int = 300):
    deleted = _cleanup_old_artifacts(limit=max(1, min(int(limit or 300), 2000)))
    return {"ok": True, "deleted": deleted, "retention_days": ARTIFACT_RETENTION_DAYS}


@app.delete("/api/v1/artifacts/{artifact_id}")
def api_delete_artifact(artifact_id: int):
    a = get_artifact(int(artifact_id))
    if not a:
        raise HTTPException(status_code=404, detail="Artifact not found")
    fp = ARTIFACT_DIR / (a.get("stored_name") or "")
    # detach from jobs first to satisfy FK constraints
    detach_artifact_from_jobs(int(artifact_id))
    delete_artifact_row(int(artifact_id))
    try:
        fp.unlink(missing_ok=True)
    except Exception:
        pass
    return {"ok": True}


@app.delete("/api/v1/documents/{doc_id}")
def api_delete_document(doc_id: int):
    doc = get_document(int(doc_id))
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")

    # 1) detach notes
    detach_document_from_notes(int(doc_id))

    # 2) delete artifacts for this document (files + DB rows)
    arts = list_artifacts_for_document(int(doc_id), limit=500)
    for a in arts:
        aid = int(a.get("id"))
        try:
            detach_artifact_from_jobs(aid)
            delete_artifact_row(aid)
        except Exception:
            pass
        try:
            (ARTIFACT_DIR / (a.get("stored_name") or "")).unlink(missing_ok=True)
        except Exception:
            pass

    # 3) delete jobs for this document
    delete_jobs_for_document(int(doc_id))

    # 4) delete document row
    delete_document_row(int(doc_id))

    # 5) delete PDF file
    try:
        (UPLOAD_DIR / (doc.get("stored_name") or "")).unlink(missing_ok=True)
    except Exception:
        pass

    return {"ok": True}


@app.post("/api/v1/pdf/compress")
def api_pdf_compress(doc_id: int = Form(...), mode: str = Form("job")):
    mode = (mode or "job").lower().strip()
    if mode in ("job", "async", "queue"):
        loaded = _get_doc_pdf_path(int(doc_id))
        if not loaded:
            raise HTTPException(status_code=404, detail="Document not found or file missing")
        return {"ok": True, "job": _enqueue_job("pdf_compress", int(doc_id), {"doc_id": int(doc_id)})}

    loaded = _load_doc_pdf_bytes(int(doc_id))
    if not loaded:
        raise HTTPException(status_code=404, detail="Document not found or file missing")

    doc, data = loaded
    out = compress_pdf_bytes(data)
    base = safe_filename(Path(doc.get("original_name", "document.pdf")).stem, "document")
    original_out = f"{base}_compressed.pdf"
    a = _create_artifact_from_bytes(
        kind="pdf_compress",
        document_id=int(doc_id),
        original_name=original_out,
        mime_type="application/pdf",
        data=out,
    )
    return {"ok": True, "item": _api_artifact_payload(a)}


@app.post("/api/v1/pdf/split")
def api_pdf_split(doc_id: int = Form(...), ranges_text: str = Form(""), mode: str = Form("job")):
    mode = (mode or "job").lower().strip()
    if mode in ("job", "async", "queue"):
        loaded = _get_doc_pdf_path(int(doc_id))
        if not loaded:
            raise HTTPException(status_code=404, detail="Document not found or file missing")
        return {"ok": True, "job": _enqueue_job("pdf_split", int(doc_id), {"doc_id": int(doc_id), "ranges_text": ranges_text or ""})}

    loaded = _load_doc_pdf_bytes(int(doc_id))
    if not loaded:
        raise HTTPException(status_code=404, detail="Document not found or file missing")

    doc, data = loaded
    ranges = parse_ranges(ranges_text or "")
    parts = split_pdf_bytes(data, ranges)
    zip_bytes = zip_files_bytes([(n, b) for (n, b) in parts], root_folder="split")
    base = safe_filename(Path(doc.get("original_name", "document.pdf")).stem, "document")
    original_out = f"{base}_split.zip"
    a = _create_artifact_from_bytes(
        kind="pdf_split_zip",
        document_id=int(doc_id),
        original_name=original_out,
        mime_type="application/zip",
        data=zip_bytes,
    )
    return {"ok": True, "item": _api_artifact_payload(a)}


@app.post("/api/v1/pdf/extract-text")
def api_pdf_extract_text(doc_id: int = Form(...), max_pages: int = Form(25), mode: str = Form("job")):
    mode = (mode or "job").lower().strip()
    if mode in ("job", "async", "queue"):
        loaded = _get_doc_pdf_path(int(doc_id))
        if not loaded:
            raise HTTPException(status_code=404, detail="Document not found or file missing")
        return {"ok": True, "job": _enqueue_job("pdf_extract_text", int(doc_id), {"doc_id": int(doc_id), "max_pages": int(max_pages or 25)})}

    loaded = _load_doc_pdf_bytes(int(doc_id))
    if not loaded:
        raise HTTPException(status_code=404, detail="Document not found or file missing")

    doc, data = loaded
    text = extract_text_from_pdf(data, max_pages=max(1, min(int(max_pages or 25), 200)))
    base = safe_filename(Path(doc.get("original_name", "document.pdf")).stem, "document")
    original_out = f"{base}_text.txt"
    a = _create_artifact_from_bytes(
        kind="pdf_text",
        document_id=int(doc_id),
        original_name=original_out,
        mime_type="text/plain; charset=utf-8",
        data=text.encode("utf-8"),
    )
    return {"ok": True, "item": _api_artifact_payload(a)}


@app.post("/api/v1/pdf/pdf-to-images")
def api_pdf_to_images(
    doc_id: int = Form(...),
    ranges_text: str = Form(""),
    dpi: int = Form(150),
    image_format: str = Form("png"),
    mode: str = Form("job"),
):
    mode = (mode or "job").lower().strip()
    if mode in ("job", "async", "queue"):
        loaded = _get_doc_pdf_path(int(doc_id))
        if not loaded:
            raise HTTPException(status_code=404, detail="Document not found or file missing")
        return {"ok": True, "job": _enqueue_job("pdf_to_images", int(doc_id), {
            "doc_id": int(doc_id),
            "ranges_text": ranges_text or "",
            "dpi": int(dpi or 150),
            "image_format": (image_format or "png"),
        })}

    loaded = _load_doc_pdf_bytes(int(doc_id))
    if not loaded:
        raise HTTPException(status_code=404, detail="Document not found or file missing")

    doc, data = loaded
    ranges = parse_ranges(ranges_text or "") if (ranges_text or "").strip() else None
    out = pdf_to_images_zip_bytes(
        data,
        ranges=ranges,
        dpi=max(72, min(int(dpi or 150), 300)),
        image_format=(image_format or "png").lower().strip(),
    )
    base = safe_filename(Path(doc.get("original_name", "document.pdf")).stem, "document")
    original_out = f"{base}_images.zip"
    a = _create_artifact_from_bytes(
        kind="pdf_images_zip",
        document_id=int(doc_id),
        original_name=original_out,
        mime_type="application/zip",
        data=out,
    )
    return {"ok": True, "item": _api_artifact_payload(a)}


@app.post("/api/v1/pdf/images-to-pdf")
async def api_images_to_pdf(
    output_name: str = Form(""),
    images: list[UploadFile] = File(...),
    mode: str = Form("job"),
):
    mode = (mode or "job").lower().strip()
    if mode in ("job", "async", "queue"):
        stored_files: list[str] = []
        for img in images:
            try:
                stored_files.append(await _store_job_input(img))
            except Exception:
                continue
        if not stored_files:
            raise HTTPException(status_code=400, detail="No images provided")
        job = _enqueue_job("images_to_pdf", None, {"image_files": stored_files, "output_name": output_name or "images"})
        return {"ok": True, "job": job}

    # sync fallback
    raw: list[bytes] = []
    for img in images:
        raw.append(await img.read())
    if not raw:
        raise HTTPException(status_code=400, detail="No images provided")
    out = images_to_pdf_bytes(raw)
    out_name = safe_filename(output_name or "images", "images") + ".pdf"
    a = _create_artifact_from_bytes(
        kind="images_to_pdf",
        document_id=None,
        original_name=out_name,
        mime_type="application/pdf",
        data=out,
    )
    return {"ok": True, "item": _api_artifact_payload(a)}


@app.post("/pdf-tools/compress", response_class=HTMLResponse)
def pdf_tools_compress(request: Request, doc_id: int = Form(...)):
    loaded = _load_doc_pdf_bytes(doc_id)
    if not loaded:
        return templates.TemplateResponse("pdf_tools.html",
                                          _pdf_tools_ctx(request,
                                                        doc_id,
                                                        "❌ Dokumentum nem található / hiányzik a fájl"),
                                          status_code=404)

    doc, data = loaded
    out = compress_pdf_bytes(data)

    base = safe_filename(Path(doc.get("original_name", "document.pdf")).stem, "document")
    original_out = f"{base}_compressed.pdf"
    a = _create_artifact_from_bytes(
        kind="pdf_compress",
        document_id=doc_id,
        original_name=original_out,
        mime_type="application/pdf",
        data=out,
    )
    aid = int(a.get("id"))

    return templates.TemplateResponse(
        "pdf_tools.html",
        _pdf_tools_ctx(request, doc_id,
                       f"✅ Tömörítés kész. Letöltés lent: #{aid} — {original_out}"),
    )


@app.post("/pdf-tools/split", response_class=HTMLResponse)
def pdf_tools_split(request: Request,
                    doc_id: int = Form(...),
                    ranges_text: str = Form("")):
    loaded = _load_doc_pdf_bytes(doc_id)
    if not loaded:
        return templates.TemplateResponse("pdf_tools.html",
                                          _pdf_tools_ctx(request,
                                                        doc_id,
                                                        "❌ Dokumentum nem található / hiányzik a fájl"),
                                          status_code=404)

    ranges = parse_ranges(ranges_text)
    if not ranges:
        return templates.TemplateResponse(
            "pdf_tools.html",
            _pdf_tools_ctx(request, doc_id,
                           "❌ Adj meg oldaltartományt pl: 1-2, 3-5"),
            status_code=400,
        )

    doc, data = loaded
    parts = split_pdf_bytes(data, ranges)

    base = safe_filename(Path(doc.get("original_name", "document.pdf")).stem, "document")
    created_ids: list[int] = []
    for fname, bts in parts:
        original_out = f"{base}_{fname}"
        a = _create_artifact_from_bytes(
            kind="pdf_split",
            document_id=doc_id,
            original_name=original_out,
            mime_type="application/pdf",
            data=bts,
        )
        created_ids.append(int(a.get("id")))

    msg = ("✅ Split kész. Letöltések lent: " + ", ".join(f"#{i}" for i in created_ids)) if created_ids else "❌ Nem készült rész"
    return templates.TemplateResponse("pdf_tools.html", _pdf_tools_ctx(request, doc_id, msg))


@app.post("/pdf-tools/extract-text", response_class=HTMLResponse)
def pdf_tools_extract_text(request: Request, doc_id: int = Form(...)):
    loaded = _load_doc_pdf_bytes(doc_id)
    if not loaded:
        return templates.TemplateResponse("pdf_tools.html",
                                          _pdf_tools_ctx(request,
                                                        doc_id,
                                                        "❌ Dokumentum nem található / hiányzik a fájl"),
                                          status_code=404)

    doc, data = loaded
    try:
        txt = extract_text_from_pdf(data, max_pages=9999) or ""
    except Exception as e:
        return templates.TemplateResponse(
            "pdf_tools.html",
            _pdf_tools_ctx(request, doc_id,
                           f"❌ Szöveg kinyerése nem sikerült: {e}"),
            status_code=400,
        )

    base = safe_filename(Path(doc.get("original_name", "document.pdf")).stem, "document")
    original_out = f"{base}.txt"
    a = _create_artifact_from_bytes(
        kind="text_export",
        document_id=doc_id,
        original_name=original_out,
        mime_type="text/plain; charset=utf-8",
        data=txt.encode("utf-8"),
    )
    aid = int(a.get("id"))

    return templates.TemplateResponse(
        "pdf_tools.html",
        _pdf_tools_ctx(request, doc_id,
                       f"✅ Szöveg export kész. Letöltés lent: #{aid} — {original_out}"),
    )


@app.post("/pdf-tools/pdf-to-images", response_class=HTMLResponse)
def pdf_tools_pdf_to_images(request: Request,
                            doc_id: int = Form(...),
                            ranges_text: str = Form(""),
                            dpi: int = Form(150),
                            fmt: str = Form("png")):
    loaded = _load_doc_pdf_bytes(doc_id)
    if not loaded:
        return templates.TemplateResponse("pdf_tools.html",
                                          _pdf_tools_ctx(request,
                                                        doc_id,
                                                        "❌ Dokumentum nem található / hiányzik a fájl"),
                                          status_code=404)

    doc, data = loaded
    ranges = parse_ranges(ranges_text) if (ranges_text or "").strip() else None
    dpi2 = max(72, min(int(dpi or 150), 300))
    fmt2 = (fmt or "png").lower()

    try:
        zip_bytes = pdf_to_images_zip_bytes(data, ranges=ranges, dpi=dpi2, image_format=fmt2)
    except Exception as e:
        return templates.TemplateResponse(
            "pdf_tools.html",
            _pdf_tools_ctx(request, doc_id,
                           f"❌ PDF→képek nem sikerült: {e}"),
            status_code=400,
        )

    base = safe_filename(Path(doc.get("original_name", "document.pdf")).stem, "document")
    original_out = f"{base}_images.zip"
    a = _create_artifact_from_bytes(
        kind="pdf_to_images_zip",
        document_id=doc_id,
        original_name=original_out,
        mime_type="application/zip",
        data=zip_bytes,
    )
    aid = int(a.get("id"))

    return templates.TemplateResponse(
        "pdf_tools.html",
        _pdf_tools_ctx(request, doc_id,
                       f"✅ PDF→képek ZIP kész. Letöltés lent: #{aid} — {original_out}"),
    )


@app.post("/pdf-tools/images-to-pdf", response_class=HTMLResponse)
async def pdf_tools_images_to_pdf(request: Request,
                                  output_name: str = Form(""),
                                  images: list[UploadFile] = File(...)):
    # Read images
    img_payloads: list[bytes] = []
    total = 0
    for f in images:
        b = await f.read()
        total += len(b)
        if total > MAX_UPLOAD_BYTES:
            return templates.TemplateResponse("pdf_tools.html", _pdf_tools_ctx(request, None, f"❌ Túl nagy feltöltés (max {MAX_UPLOAD_MB}MB összesen)"), status_code=413)
        img_payloads.append(b)

    try:
        pdf_bytes = images_to_pdf_bytes(img_payloads)
    except Exception as e:
        return templates.TemplateResponse(
            "pdf_tools.html",
            _pdf_tools_ctx(request, None, f"❌ Képek→PDF nem sikerült: {e}"),
            status_code=400,
        )

    base = safe_filename((output_name or "images").strip() or "images", "images")
    original_out = f"{base}.pdf"
    a = _create_artifact_from_bytes(
        kind="images_to_pdf",
        document_id=None,
        original_name=original_out,
        mime_type="application/pdf",
        data=pdf_bytes,
    )
    aid = int(a.get("id"))

    return templates.TemplateResponse(
        "pdf_tools.html",
        _pdf_tools_ctx(request, None,
                       f"✅ Képek→PDF kész. Letöltés lent: #{aid} — {original_out}"),
    )

# --- Replit/CLI entrypoint ---
# Running `python main.py` will start the FastAPI server.
if __name__ == "__main__":
    import uvicorn

    port = int(os.getenv("PORT") or os.getenv("REPLIT_PORT") or "3000")
    # Reload is optional; keep it OFF by default for stability.
    reload_flag = (os.getenv("RELOAD") or "0").strip() in {"1", "true", "True", "yes"}
    uvicorn.run(app, host="0.0.0.0", port=port, reload=reload_flag)
