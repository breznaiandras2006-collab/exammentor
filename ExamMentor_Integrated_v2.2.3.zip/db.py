# db.py
from __future__ import annotations

import sqlite3
from typing import Any, Dict, List, Optional

DB_PATH = "app.db"


def get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA foreign_keys=ON")
    except Exception:
        pass
    return conn


def init_db() -> None:
    conn = get_conn()
    cur = conn.cursor()

    cur.execute("""
    CREATE TABLE IF NOT EXISTS documents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      original_name TEXT NOT NULL,
      stored_name TEXT NOT NULL,
      language TEXT DEFAULT 'auto',
      pages INTEGER DEFAULT 0,
      doc_type TEXT DEFAULT 'pdf',
      search_text TEXT DEFAULT '',
      created_at TEXT DEFAULT (datetime('now'))
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS notes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      body TEXT NOT NULL,
      body_format TEXT NOT NULL DEFAULT 'markdown',
      version INTEGER NOT NULL DEFAULT 1,
      last_client_rev TEXT NOT NULL DEFAULT '',
      document_id INTEGER NULL,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY(document_id) REFERENCES documents(id)
    )
    """)

    # Notes schema migrations (safe ALTER for older DBs)
    _ensure_column(cur, "notes", "body_format", "TEXT NOT NULL DEFAULT 'markdown'")
    _ensure_column(cur, "notes", "version", "INTEGER NOT NULL DEFAULT 1")
    _ensure_column(cur, "notes", "last_client_rev", "TEXT NOT NULL DEFAULT ''")
    # ALTER TABLE ADD COLUMN default expressions are restricted → use CURRENT_TIMESTAMP for safety
    _ensure_column(cur, "notes", "updated_at", "TEXT DEFAULT CURRENT_TIMESTAMP")

    # Note versions / history table
    cur.execute("""
    CREATE TABLE IF NOT EXISTS note_versions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      note_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      body TEXT NOT NULL,
      body_format TEXT NOT NULL DEFAULT 'markdown',
      version INTEGER NOT NULL,
      client_rev TEXT NOT NULL DEFAULT '',
      created_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY(note_id) REFERENCES notes(id) ON DELETE CASCADE
    )
    """)

    # Quiz tables (single-user, session-based)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS quiz_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      document_id INTEGER NULL,
      title TEXT NOT NULL DEFAULT '',
      mode TEXT NOT NULL DEFAULT 'exam',
      params_json TEXT NOT NULL DEFAULT '{}',
      created_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY(document_id) REFERENCES documents(id)
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS quiz_attempts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id INTEGER NOT NULL,
      question_index INTEGER NOT NULL DEFAULT 0,
      question_json TEXT NOT NULL,
      answer_json TEXT NOT NULL DEFAULT '{}',
      is_correct INTEGER NOT NULL DEFAULT 0,
      score REAL NOT NULL DEFAULT 0,
      created_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY(session_id) REFERENCES quiz_sessions(id) ON DELETE CASCADE
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS card_bank (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      document_id INTEGER NULL,
      tags TEXT NOT NULL DEFAULT '',
      card_json TEXT NOT NULL,
      created_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY(document_id) REFERENCES documents(id)
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS card_stats (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      card_id INTEGER NOT NULL,
      attempts INTEGER NOT NULL DEFAULT 0,
      correct INTEGER NOT NULL DEFAULT 0,
      last_seen_at TEXT NULL,
      created_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY(card_id) REFERENCES card_bank(id) ON DELETE CASCADE
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS user_progress (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      document_id INTEGER NULL,
      metric_key TEXT NOT NULL,
      metric_value TEXT NOT NULL DEFAULT '',
      updated_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY(document_id) REFERENCES documents(id)
    )
    """)

    # Settings (compat): some snapshots use a single-row "settings" table with columns,
    # others use key-value. To keep stability, we support BOTH:
    #  - settings: row-based columns (legacy)
    #  - settings_kv: key-value for extra/new keys
    cur.execute("""
    CREATE TABLE IF NOT EXISTS settings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      answer_language TEXT DEFAULT 'auto',
      manual_mode INTEGER DEFAULT 0,
      translation_style TEXT DEFAULT 'natural',
      default_gpt_mode TEXT DEFAULT 'exam',
      default_language TEXT DEFAULT 'auto',
      theme TEXT DEFAULT 'dark'
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS settings_kv (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    )
    """)

    _ensure_settings_row(cur)

    # defaults (set in row-table when possible; also mirrored into kv for forward-compat)
    _set_default_setting(cur, "ui_lang", "hu")
    _set_default_setting(cur, "answer_language", "hu")
    _set_default_setting(cur, "theme", "dark")
    _set_default_setting(cur, "manual_mode", "0")
    _set_default_setting(cur, "translation_style", "natural")
    _set_default_setting(cur, "default_gpt_mode", "exam")

    # generated outputs (PDF tools, exports, etc.)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS artifacts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      kind TEXT NOT NULL,
      document_id INTEGER NULL,
      original_name TEXT NOT NULL,
      stored_name TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      size_bytes INTEGER DEFAULT 0,
      created_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY(document_id) REFERENCES documents(id)
    )
    """)

    # background jobs (for long-running tasks: PDF conversions, OCR, PPT, etc.)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS jobs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      kind TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'queued', -- queued|running|succeeded|failed
      document_id INTEGER NULL,
      artifact_id INTEGER NULL,
      params_json TEXT NOT NULL DEFAULT '{}',
      progress INTEGER NOT NULL DEFAULT 0,
      progress_json TEXT NOT NULL DEFAULT '{}',
      cancel_requested INTEGER NOT NULL DEFAULT 0,
      error TEXT NULL,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      started_at TEXT NULL,
      finished_at TEXT NULL,
      FOREIGN KEY(document_id) REFERENCES documents(id),
      FOREIGN KEY(artifact_id) REFERENCES artifacts(id)
    )
    """)

    # Jobs schema migrations (safe ALTER)
    _ensure_column(cur, "jobs", "progress", "INTEGER NOT NULL DEFAULT 0")
    _ensure_column(cur, "jobs", "progress_json", "TEXT NOT NULL DEFAULT '{}'")
    _ensure_column(cur, "jobs", "cancel_requested", "INTEGER NOT NULL DEFAULT 0")
    _ensure_column(cur, "jobs", "updated_at", "TEXT DEFAULT CURRENT_TIMESTAMP")

    # Optional OCR job extension (keeps base jobs table generic)
    # NOTE: create AFTER jobs exists, otherwise FK validation may fail.
    cur.execute("""
    CREATE TABLE IF NOT EXISTS ocr_jobs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      job_id INTEGER NOT NULL UNIQUE,
      pages_total INTEGER NOT NULL DEFAULT 0,
      pages_done INTEGER NOT NULL DEFAULT 0,
      language TEXT NOT NULL DEFAULT 'auto',
      engine TEXT NOT NULL DEFAULT 'auto',
      updated_at TEXT DEFAULT (datetime('now')),
      created_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY(job_id) REFERENCES jobs(id) ON DELETE CASCADE
    )
    """)

    # indexes (idempotent)
    cur.execute("CREATE INDEX IF NOT EXISTS idx_notes_document_id ON notes(document_id)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_note_versions_note_id ON note_versions(note_id)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_quiz_attempts_session_id ON quiz_attempts(session_id)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_user_progress_doc_key ON user_progress(document_id, metric_key)")


    conn.commit()
    conn.close()


def _ensure_column(cur: sqlite3.Cursor, table: str, column: str, ddl: str) -> None:
    """Ensure a column exists on a table (SQLite-safe migration).

    ddl example: "TEXT NOT NULL DEFAULT ''".
    """
    try:
        cur.execute(f"PRAGMA table_info({table})")
        cols = [r[1] for r in cur.fetchall()]  # (cid, name, type, ...)
        if column in cols:
            return
        cur.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")
    except Exception:
        # never block boot; worst case the new feature will be disabled
        return


def _settings_columns(cur: sqlite3.Cursor) -> List[str]:
    """Return column names for legacy row-based settings table."""
    try:
        cur.execute("PRAGMA table_info(settings)")
        return [r[1] for r in cur.fetchall()]
    except Exception:
        return []


def _ensure_settings_row(cur: sqlite3.Cursor) -> None:
    """Ensure the legacy row-based settings table has exactly one row."""
    try:
        cur.execute("SELECT COUNT(*) FROM settings")
        cnt = int(cur.fetchone()[0])
        if cnt <= 0:
            cur.execute("INSERT INTO settings DEFAULT VALUES")
    except Exception:
        return


_SETTINGS_KEY_MAP = {
    # ui_lang was used as a UI preference in some snapshots; map to default_language for legacy.
    "ui_lang": "default_language",
}


def _set_default_setting(cur: sqlite3.Cursor, key: str, value: str) -> None:
    """Set default setting for both schemas (legacy row table + kv table)."""
    # 1) legacy row-table if column exists
    cols = _settings_columns(cur)
    col = _SETTINGS_KEY_MAP.get(key, key)
    try:
        if col in cols:
            cur.execute(f"SELECT {col} FROM settings LIMIT 1")
            row = cur.fetchone()
            current = row[0] if row else None
            if current is None or str(current) == "":
                cur.execute(f"UPDATE settings SET {col} = ? WHERE id = (SELECT id FROM settings LIMIT 1)", (value,))
    except Exception:
        pass

    # 2) key-value table for forward-compat + extra keys
    try:
        cur.execute("SELECT value FROM settings_kv WHERE key = ?", (key,))
        r = cur.fetchone()
        if r is None:
            cur.execute("INSERT INTO settings_kv(key, value) VALUES(?, ?)", (key, value))
    except Exception:
        return


# ---------- settings ----------
def get_all_settings() -> Dict[str, str]:
    conn = get_conn()
    cur = conn.cursor()
    out: Dict[str, str] = {}

    # legacy row-based settings
    try:
        cols = _settings_columns(cur)
        cols_no_id = [c for c in cols if c and c != "id"]
        if cols_no_id:
            cur.execute(f"SELECT {', '.join(cols_no_id)} FROM settings LIMIT 1")
            row = cur.fetchone()
            if row:
                for i, c in enumerate(cols_no_id):
                    v = row[i]
                    if v is not None:
                        out[c] = str(v)
                # alias
                if "default_language" in out and "ui_lang" not in out:
                    out["ui_lang"] = out["default_language"]
    except Exception:
        pass

    # key-value settings (overrides/extends)
    try:
        cur.execute("SELECT key, value FROM settings_kv")
        for r in cur.fetchall():
            out[str(r["key"])] = str(r["value"])
    except Exception:
        pass

    conn.close()
    return out


def get_setting(key: str, default: str = "") -> str:
    conn = get_conn()
    cur = conn.cursor()

    # key-value first (new)
    try:
        cur.execute("SELECT value FROM settings_kv WHERE key = ?", (key,))
        r = cur.fetchone()
        if r is not None:
            conn.close()
            return str(r["value"])
    except Exception:
        pass

    # legacy row-based
    try:
        col = _SETTINGS_KEY_MAP.get(key, key)
        cols = _settings_columns(cur)
        if col in cols:
            cur.execute(f"SELECT {col} FROM settings LIMIT 1")
            r = cur.fetchone()
            conn.close()
            return str(r[0]) if r and r[0] is not None else default
    except Exception:
        pass

    conn.close()
    return default


def set_setting(key: str, value: str) -> None:
    conn = get_conn()
    cur = conn.cursor()

    # legacy row-based update when column exists
    try:
        col = _SETTINGS_KEY_MAP.get(key, key)
        cols = _settings_columns(cur)
        if col in cols:
            _ensure_settings_row(cur)
            cur.execute(
                f"UPDATE settings SET {col} = ? WHERE id = (SELECT id FROM settings LIMIT 1)",
                (value,),
            )
    except Exception:
        pass

    # key-value upsert for forward-compat
    try:
        cur.execute(
            """
            INSERT INTO settings_kv(key, value) VALUES(?, ?)
            ON CONFLICT(key) DO UPDATE SET value=excluded.value
            """,
            (key, value),
        )
    except Exception:
        pass

    conn.commit()
    conn.close()


# ---------- documents ----------
def insert_document(title: str, original_name: str, stored_name: str,
                    language: str, pages: int, doc_type: str,
                    search_text: str) -> int:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """
    INSERT INTO documents(title, original_name, stored_name, language, pages, doc_type, search_text)
    VALUES(?,?,?,?,?,?,?)
    """, (title, original_name, stored_name, language, int(pages), doc_type,
          search_text))
    conn.commit()
    doc_id = cur.lastrowid
    conn.close()
    return int(doc_id)


def list_documents() -> List[Dict[str, Any]]:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM documents ORDER BY id DESC")
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_document(doc_id: int) -> Optional[Dict[str, Any]]:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM documents WHERE id = ?", (int(doc_id), ))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def search_documents(q: str, limit: int = 8) -> List[Dict[str, Any]]:
    q2 = f"%{(q or '').strip()}%"
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """
    SELECT * FROM documents
    WHERE title LIKE ? OR search_text LIKE ? OR original_name LIKE ?
    ORDER BY id DESC
    LIMIT ?
    """, (q2, q2, q2, int(limit)))
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ---------- notes ----------
def insert_note(title: str,
                body: str,
                document_id: Optional[int] = None) -> int:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """
    INSERT INTO notes(title, body, document_id)
    VALUES(?,?,?)
    """, (title, body, document_id))
    conn.commit()
    nid = cur.lastrowid
    conn.close()
    return int(nid)


def list_notes(limit: int = 50) -> List[Dict[str, Any]]:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """
    SELECT * FROM notes
    ORDER BY id DESC
    LIMIT ?
    """, (int(limit), ))
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_note(note_id: int) -> Optional[Dict[str, Any]]:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM notes WHERE id = ?", (int(note_id), ))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def update_note(note_id: int, title: str, body: str,
                document_id: Optional[int]) -> None:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """
    UPDATE notes SET title=?, body=?, document_id=? WHERE id=?
    """, (title, body, document_id, int(note_id)))
    conn.commit()
    conn.close()


def search_notes(q: str,
                 document_id: Optional[int] = None,
                 limit: int = 12) -> List[Dict[str, Any]]:
    q2 = f"%{(q or '').strip()}%"
    conn = get_conn()
    cur = conn.cursor()

    if document_id is None:
        cur.execute(
            """
        SELECT * FROM notes
        WHERE title LIKE ? OR body LIKE ?
        ORDER BY id DESC
        LIMIT ?
        """, (q2, q2, int(limit)))
    else:
        cur.execute(
            """
        SELECT * FROM notes
        WHERE (title LIKE ? OR body LIKE ?) AND document_id=?
        ORDER BY id DESC
        LIMIT ?
        """, (q2, q2, int(document_id), int(limit)))

    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]
# ---------- jobs ----------
def insert_job(kind: str,
               params_json: str = "{}",
               status: str = "queued",
               document_id: Optional[int] = None) -> int:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """
    INSERT INTO jobs(kind, status, document_id, params_json)
    VALUES(?,?,?,?)
    """,
        (kind, status, document_id, params_json or "{}"),
    )
    job_id = int(cur.lastrowid)
    conn.commit()
    conn.close()
    return job_id


def update_job(job_id: int,
               *,
               status: Optional[str] = None,
               artifact_id: Optional[int] = None,
               error: Optional[str] = None,
               started_at: Optional[str] = None,
               finished_at: Optional[str] = None) -> None:
    fields = []
    values: List[Any] = []
    if status is not None:
        fields.append("status = ?")
        values.append(status)
    if artifact_id is not None:
        fields.append("artifact_id = ?")
        values.append(int(artifact_id))
    if error is not None:
        fields.append("error = ?")
        values.append(error)
    if started_at is not None:
        fields.append("started_at = ?")
        values.append(started_at)
    if finished_at is not None:
        fields.append("finished_at = ?")
        values.append(finished_at)

    if not fields:
        return

    conn = get_conn()
    cur = conn.cursor()
    cur.execute(f"UPDATE jobs SET {', '.join(fields)} WHERE id = ?", (*values, int(job_id)))
    conn.commit()
    conn.close()


def get_job(job_id: int) -> Optional[Dict[str, Any]]:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM jobs WHERE id = ?", (int(job_id),))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def list_jobs(limit: int = 100) -> List[Dict[str, Any]]:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """
    SELECT * FROM jobs
    ORDER BY id DESC
    LIMIT ?
    """,
        (max(1, min(int(limit or 100), 200)),),
    )
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]

# ---------- artifacts ----------
def insert_artifact(kind: str,
                    original_name: str,
                    stored_name: str,
                    mime_type: str,
                    size_bytes: int = 0,
                    document_id: Optional[int] = None) -> int:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """
    INSERT INTO artifacts(kind, document_id, original_name, stored_name, mime_type, size_bytes)
    VALUES(?,?,?,?,?,?)
    """, (kind, document_id, original_name, stored_name, mime_type, int(size_bytes)))
    conn.commit()
    aid = cur.lastrowid
    conn.close()
    return int(aid)


def list_artifacts(limit: int = 30) -> List[Dict[str, Any]]:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """
    SELECT * FROM artifacts
    ORDER BY id DESC
    LIMIT ?
    """, (int(limit), ))
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def list_artifacts_for_document(document_id: int,
                               limit: int = 30) -> List[Dict[str, Any]]:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """
    SELECT * FROM artifacts
    WHERE document_id = ?
    ORDER BY id DESC
    LIMIT ?
    """, (int(document_id), int(limit)))
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_artifact(artifact_id: int) -> Optional[Dict[str, Any]]:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM artifacts WHERE id = ?", (int(artifact_id), ))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def detach_artifact_from_jobs(artifact_id: int) -> None:
    """Set jobs.artifact_id = NULL for jobs referencing this artifact."""
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("UPDATE jobs SET artifact_id = NULL WHERE artifact_id = ?", (int(artifact_id),))
    conn.commit()
    conn.close()


def delete_artifact_row(artifact_id: int) -> None:
    """Delete artifact row from DB. Call detach_artifact_from_jobs first if needed."""
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("DELETE FROM artifacts WHERE id = ?", (int(artifact_id),))
    conn.commit()
    conn.close()


def list_artifacts_older_than(days: int, limit: int = 200) -> List[Dict[str, Any]]:
    """Artifacts older than N days, excluding ones referenced by jobs."""
    d = max(1, int(days or 7))
    lim = max(1, min(int(limit or 200), 1000))
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """
        SELECT * FROM artifacts
        WHERE datetime(created_at) < datetime('now', ?)
          AND id NOT IN (SELECT artifact_id FROM jobs WHERE artifact_id IS NOT NULL)
        ORDER BY id ASC
        LIMIT ?
        """,
        (f"-{d} days", lim),
    )
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def detach_document_from_notes(document_id: int) -> None:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("UPDATE notes SET document_id = NULL WHERE document_id = ?", (int(document_id),))
    conn.commit()
    conn.close()


def delete_jobs_for_document(document_id: int) -> None:
    conn = get_conn()
    cur = conn.cursor()
    # detach artifacts first to avoid FK issues on artifact deletion
    cur.execute("UPDATE jobs SET artifact_id = NULL WHERE document_id = ?", (int(document_id),))
    cur.execute("DELETE FROM jobs WHERE document_id = ?", (int(document_id),))
    conn.commit()
    conn.close()


def delete_document_row(document_id: int) -> None:
    """Delete document row from DB (no file operations)."""
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("DELETE FROM documents WHERE id = ?", (int(document_id),))
    conn.commit()
    conn.close()
