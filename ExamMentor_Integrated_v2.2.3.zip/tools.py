# tools.py
from __future__ import annotations

import io
import re
import shutil
import unicodedata
import zipfile
from pathlib import Path
from typing import Callable, List, Optional, Tuple

from pypdf import PdfReader, PdfWriter

# Optional dependencies
try:
    import fitz  # PyMuPDF
except Exception:  # pragma: no cover
    fitz = None

try:
    from PIL import Image  # type: ignore
except Exception:  # pragma: no cover
    Image = None


class OcrCancelled(Exception):
    """Raised when an OCR job is cancelled (best-effort)."""


# ---------------- Helpers ----------------

def safe_filename(name: str, fallback: str = "file.pdf") -> str:
    """Makes a filename safe for saving on filesystem."""
    name = (name or "").strip()
    if not name:
        return fallback

    # normalize
    name = unicodedata.normalize("NFKD", name)
    name = name.encode("ascii", "ignore").decode("ascii")
    name = name.lower()

    # replace spaces and invalid chars
    name = re.sub(r"\s+", "_", name)
    name = re.sub(r"[^a-z0-9._-]+", "", name)
    name = re.sub(r"_+", "_", name).strip("._-")

    return name or fallback


def make_snippet(text: str, q: str, radius: int = 80) -> str:
    """Returns a small snippet around the first occurrence of q in text."""
    t = (text or "")
    q2 = (q or "").strip()
    if not t:
        return ""
    if not q2:
        return (t[: radius * 2] + "…") if len(t) > radius * 2 else t

    low_t = t.lower()
    low_q = q2.lower()
    idx = low_t.find(low_q)
    if idx < 0:
        return (t[: radius * 2] + "…") if len(t) > radius * 2 else t

    start = max(0, idx - radius)
    end = min(len(t), idx + len(q2) + radius)
    prefix = "…" if start > 0 else ""
    suffix = "…" if end < len(t) else ""
    return prefix + t[start:end].replace("\n", " ").strip() + suffix


# ---------------- PDF basics ----------------

def pdf_page_count(pdf_bytes: bytes) -> int:
    reader = PdfReader(io.BytesIO(pdf_bytes))
    return len(reader.pages)


def pdf_page_count_path(pdf_path: str | Path) -> int:
    """Count pages without loading whole file into memory."""
    p = Path(pdf_path)
    reader = PdfReader(str(p))
    return len(reader.pages)


def extract_text_from_pdf(
    pdf_bytes: bytes,
    max_pages: int = 25,
    pages: Optional[List[int]] = None,
) -> str:
    """Simple text extraction from PDF (pypdf).

    - Good for text-based PDFs.
    - If `pages` is provided (1-based), extracts only those pages (best-effort).
    """
    reader = PdfReader(io.BytesIO(pdf_bytes))
    out: List[str] = []

    total = len(reader.pages)
    if pages:
        seen = set()
        for p in pages:
            try:
                n = int(p)
            except Exception:
                continue
            if n < 1 or n > total or n in seen:
                continue
            seen.add(n)
            try:
                out.append(reader.pages[n - 1].extract_text() or "")
            except Exception:
                out.append("")
        return "\n".join(out).strip()

    limit = max(1, int(max_pages or 25))
    for page in reader.pages[:limit]:
        try:
            out.append(page.extract_text() or "")
        except Exception:
            out.append("")
    return "\n".join(out).strip()


def extract_text_from_pdf_path(pdf_path: str | Path, max_pages: int = 25) -> str:
    """Extract text from a PDF path. Best-effort; returns '' on failure."""
    p = Path(pdf_path)
    try:
        reader = PdfReader(str(p))
    except Exception:
        return ""

    out: List[str] = []
    limit = max(1, int(max_pages or 25))
    for i, page in enumerate(reader.pages):
        if i >= limit:
            break
        try:
            out.append(page.extract_text() or "")
        except Exception:
            continue
    return "\n".join([t for t in out if t]).strip()


def compress_pdf_bytes(pdf_bytes: bytes) -> bytes:
    """Basic compression by rewriting PDF and compressing streams (best-effort)."""
    reader = PdfReader(io.BytesIO(pdf_bytes))
    writer = PdfWriter()

    for p in reader.pages:
        writer.add_page(p)

    try:
        writer.compress_content_streams()
    except Exception:
        pass

    buf = io.BytesIO()
    writer.write(buf)
    return buf.getvalue()


def split_pdf_bytes(pdf_bytes: bytes, ranges: List[Tuple[int, int]]) -> List[Tuple[str, bytes]]:
    """Split PDF by 1-based inclusive ranges. Returns (filename, bytes) list."""
    reader = PdfReader(io.BytesIO(pdf_bytes))
    total = len(reader.pages)

    outputs: List[Tuple[str, bytes]] = []
    for idx, (a, b) in enumerate(ranges, start=1):
        a = max(1, int(a))
        b = min(total, int(b))
        if a > b:
            continue

        writer = PdfWriter()
        for p in range(a - 1, b):
            writer.add_page(reader.pages[p])

        buf = io.BytesIO()
        writer.write(buf)
        outputs.append((f"split_{idx}_{a}-{b}.pdf", buf.getvalue()))

    return outputs


def zip_files_bytes(files: List[Tuple[str, bytes]], root_folder: str = "") -> bytes:
    """Create a ZIP archive in-memory from (filename, bytes) pairs."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for name, bts in files:
            name2 = safe_filename(name or "file.bin", "file.bin")
            arc = f"{root_folder.strip().rstrip('/')}/{name2}" if root_folder else name2
            z.writestr(arc, bts or b"")
    return buf.getvalue()


def parse_ranges(ranges_text: str) -> List[Tuple[int, int]]:
    """Parse '1-3,5' -> [(1,3),(5,5)]."""
    s = (ranges_text or "").strip()
    if not s:
        return []

    parts = [p.strip() for p in s.split(",") if p.strip()]
    out: List[Tuple[int, int]] = []
    for p in parts:
        if "-" in p:
            x, y = p.split("-", 1)
            out.append((int(x.strip()), int(y.strip())))
        else:
            n = int(p)
            out.append((n, n))
    return out


def page_list_from_ranges(ranges_text: str, total_pages: int) -> List[int]:
    """Parse ranges into a sorted, de-duplicated 1-based page list."""
    total = max(0, int(total_pages or 0))
    if total <= 0:
        return []

    ranges = parse_ranges(ranges_text)
    if not ranges:
        return []

    out: List[int] = []
    seen = set()
    for a, b in ranges:
        try:
            a2 = int(a)
            b2 = int(b)
        except Exception:
            continue
        lo, hi = (a2, b2) if a2 <= b2 else (b2, a2)
        lo = max(1, lo)
        hi = min(total, hi)
        for n in range(lo, hi + 1):
            if n in seen:
                continue
            seen.add(n)
            out.append(n)
    return out


# ---------------- PDF conversions (crossplatform base) ----------------

def pdf_to_images_zip_bytes(
    pdf_bytes: bytes,
    ranges: Optional[List[Tuple[int, int]]] = None,
    dpi: int = 150,
    image_format: str = "png",
) -> bytes:
    """Render selected PDF pages to images and return a ZIP as bytes.

    Requires PyMuPDF (pymupdf).
    ranges: list of (start,end) 1-based inclusive. If None/empty -> all pages.
    """
    if fitz is None:
        raise RuntimeError("PyMuPDF (pymupdf) is not installed")

    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    total = doc.page_count

    indices: List[int] = []
    if ranges:
        for a, b in ranges:
            a = max(1, int(a))
            b = min(total, int(b))
            if a > b:
                continue
            indices.extend(list(range(a - 1, b)))
    else:
        indices = list(range(total))

    indices = sorted(set(i for i in indices if 0 <= i < total))

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        for i in indices:
            page = doc.load_page(i)
            pix = page.get_pixmap(dpi=int(dpi))
            fmt = (image_format or "png").lower()
            if fmt not in ("png", "jpg", "jpeg"):
                fmt = "png"

            ext = "jpg" if fmt in ("jpg", "jpeg") else "png"
            name = f"page_{i + 1:03d}.{ext}"
            img_bytes = pix.tobytes("jpeg") if ext == "jpg" else pix.tobytes("png")
            zf.writestr(name, img_bytes)

    doc.close()
    return buf.getvalue()


def images_to_pdf_bytes(images: List[bytes]) -> bytes:
    """Create a single PDF from multiple image byte payloads.

    Requires Pillow.
    """
    if Image is None:
        raise RuntimeError("Pillow is not installed")
    if not images:
        raise ValueError("No images provided")

    pil_images: List[Image.Image] = []
    for b in images:
        im = Image.open(io.BytesIO(b))
        if im.mode != "RGB":
            im = im.convert("RGB")
        pil_images.append(im)

    first, rest = pil_images[0], pil_images[1:]
    out = io.BytesIO()
    first.save(out, format="PDF", save_all=True, append_images=rest)
    return out.getvalue()


# ---------------- Merge / Rotate (v3) ----------------

def _rotate_page_best_effort(page, degrees: int) -> None:
    """Rotate a pypdf page in-place (best-effort across pypdf versions)."""
    deg = int(degrees or 0) % 360
    if deg == 0:
        return
    if deg not in (90, 180, 270):
        raise ValueError("Rotate degrees must be 90/180/270")

    try:
        page.rotate(deg)  # newer pypdf
        return
    except Exception:
        pass

    try:
        if deg == 90:
            page.rotate_clockwise(90)
        elif deg == 180:
            page.rotate_clockwise(180)
        elif deg == 270:
            page.rotate_counter_clockwise(90)
    except Exception:
        return


def merge_rotate_pdf_bytes_v3(
    pdf_items: List[Tuple[bytes, int]],
    rotate_degrees: int = 0,
    rotate_pages: Optional[List[int]] = None,
) -> bytes:
    """Merge PDFs with optional per-document rotation and optional output rotation."""
    if not pdf_items:
        raise ValueError("No PDFs provided")

    out_deg = int(rotate_degrees or 0) % 360
    out_do_rotate = out_deg in (90, 180, 270)
    rotate_set = set(int(p) for p in (rotate_pages or []) if int(p) > 0)
    rotate_all = out_do_rotate and not rotate_set

    writer = PdfWriter()
    global_page = 0

    for bts, doc_deg_raw in pdf_items:
        doc_deg = int(doc_deg_raw or 0) % 360
        doc_do_rotate = doc_deg in (90, 180, 270)
        reader = PdfReader(io.BytesIO(bts))
        for page in reader.pages:
            if doc_do_rotate:
                _rotate_page_best_effort(page, doc_deg)

            global_page += 1
            if out_do_rotate and (rotate_all or (global_page in rotate_set)):
                _rotate_page_best_effort(page, out_deg)

            writer.add_page(page)

    try:
        writer.compress_content_streams()
    except Exception:
        pass

    buf = io.BytesIO()
    writer.write(buf)
    return buf.getvalue()


# ---------------- OCR (optional) ----------------

def _import_pil_image():
    try:
        from PIL import Image as _Image  # type: ignore

        return _Image
    except Exception:
        return None


def _import_fitz():
    try:
        import fitz as _fitz  # type: ignore

        return _fitz
    except Exception:
        return None


def _import_pytesseract():
    try:
        import pytesseract  # type: ignore

        return pytesseract
    except Exception:
        return None


def extract_text_from_pdf_fitz(
    pdf_bytes: bytes,
    max_pages: int = 25,
    pages: Optional[List[int]] = None,
) -> str:
    """Text extraction using PyMuPDF (fitz) as a best-effort fallback."""
    _fitz = _import_fitz()
    if _fitz is None:
        return ""

    try:
        doc = _fitz.open(stream=pdf_bytes, filetype="pdf")
    except Exception:
        return ""

    out: List[str] = []
    total = len(doc)
    if total <= 0:
        return ""

    if pages:
        seen = set()
        for p in pages:
            try:
                n = int(p)
            except Exception:
                continue
            if n < 1 or n > total or n in seen:
                continue
            seen.add(n)
            try:
                page = doc.load_page(n - 1)
                out.append(page.get_text("text") or "")
            except Exception:
                out.append("")
        return "\n".join(out).strip()

    n_pages = min(total, max(1, int(max_pages)))
    for i in range(n_pages):
        try:
            page = doc.load_page(i)
            out.append(page.get_text("text") or "")
        except Exception:
            out.append("")
    return "\n".join(out).strip()


def ocr_pdf_to_text(
    pdf_bytes: bytes,
    max_pages: int = 10,
    dpi: int = 200,
    lang: str = "eng",
    pages: Optional[List[int]] = None,
    progress_cb: Optional[Callable[[int, int, str], None]] = None,
    cancel_cb: Optional[Callable[[], bool]] = None,
) -> str:
    """OCR a PDF into plain text (optional deps).

    Requires:
      - PyMuPDF (fitz)
      - Pillow
      - pytesseract + system `tesseract`
    """
    _fitz = _import_fitz()
    _Image = _import_pil_image()
    pytesseract = _import_pytesseract()

    if _fitz is None:
        raise RuntimeError("OCR backend missing: install PyMuPDF (pip install PyMuPDF).")
    if _Image is None:
        raise RuntimeError("OCR backend missing: install Pillow (pip install Pillow).")
    if pytesseract is None:
        raise RuntimeError(
            "OCR backend missing: install pytesseract (pip install pytesseract) and ensure `tesseract` is installed on the OS."  # noqa: E501
        )

    if shutil.which("tesseract") is None:
        raise RuntimeError(
            "OCR backend missing: system `tesseract` binary not found.\n\n"
            "Replit tipp: ellenőrizd, hogy a replit.nix tartalmazza: pkgs.tesseract\n"
            "Majd 'Rebuild' a Replitben.\n"
        )

    doc = _fitz.open(stream=pdf_bytes, filetype="pdf")
    out_parts: List[str] = []

    scale = max(1.0, float(dpi) / 72.0)
    mat = _fitz.Matrix(scale, scale)

    total = len(doc)
    if total <= 0:
        return ""

    if pages:
        chosen: List[int] = []
        seen = set()
        for p in pages:
            try:
                n = int(p)
            except Exception:
                continue
            if n < 1 or n > total or n in seen:
                continue
            seen.add(n)
            chosen.append(n)
    else:
        n_pages = min(total, max(1, int(max_pages)))
        chosen = list(range(1, n_pages + 1))

    used_fallback = False
    total_chosen = len(chosen)

    if progress_cb:
        try:
            progress_cb(0, max(1, total_chosen), "OCR starting")
        except Exception:
            pass

    if cancel_cb:
        try:
            if cancel_cb():
                raise OcrCancelled("OCR cancelled")
        except OcrCancelled:
            raise
        except Exception:
            pass

    for idx, pnum in enumerate(chosen, start=1):
        if cancel_cb:
            try:
                if bool(cancel_cb()):
                    raise OcrCancelled("OCR cancelled")
            except OcrCancelled:
                raise
            except Exception:
                pass

        if progress_cb:
            try:
                progress_cb(idx - 1, max(1, total_chosen), f"OCR page {idx}/{max(1, total_chosen)} (pdf page {pnum})")
            except Exception:
                pass

        page = doc.load_page(pnum - 1)
        pix = page.get_pixmap(matrix=mat, alpha=False)
        img = _Image.frombytes("RGB", (pix.width, pix.height), pix.samples)

        req_lang = (lang or "eng").strip()
        try:
            text = pytesseract.image_to_string(img, lang=req_lang)
        except Exception as e:
            if (req_lang != "eng") and (not used_fallback):
                try:
                    text = pytesseract.image_to_string(img, lang="eng")
                    used_fallback = True
                except Exception:
                    raise RuntimeError(
                        f"Tesseract OCR failed (lang='{req_lang}'). Try lang='eng' or install the language data for '{req_lang}'.\n\n"
                        f"Original error: {e}"
                    )
            else:
                raise RuntimeError(f"Tesseract OCR failed (lang='{req_lang}'): {e}")

        text = (text or "").strip()
        if text:
            out_parts.append(text)

        if progress_cb:
            try:
                progress_cb(idx, max(1, total_chosen), f"OCR page {idx}/{max(1, total_chosen)} (pdf page {pnum})")
            except Exception:
                pass

    if progress_cb:
        try:
            progress_cb(max(1, total_chosen), max(1, total_chosen), "OCR done")
        except Exception:
            pass

    if used_fallback:
        out_parts.insert(
            0,
            "[!] OCR fallback: requested language missing, used lang='eng' for at least one page.",
        )

    return "\n\n".join(out_parts).strip()


def pdf_text_or_ocr(
    pdf_bytes: bytes,
    max_pages_text: int = 25,
    ocr_max_pages: int = 10,
    ocr_lang: str = "eng",
    pages: Optional[List[int]] = None,
) -> str:
    """Best-effort: try pypdf text → fitz text → OCR."""
    try:
        txt = extract_text_from_pdf(pdf_bytes, max_pages=max_pages_text, pages=pages)
    except Exception:
        txt = ""

    if len((txt or "").strip()) >= 80:
        return txt.strip()

    try:
        txt2 = extract_text_from_pdf_fitz(pdf_bytes, max_pages=max_pages_text, pages=pages)
    except Exception:
        txt2 = ""

    if len((txt2 or "").strip()) >= 80:
        return txt2.strip()

    ocr_txt = ocr_pdf_to_text(
        pdf_bytes,
        max_pages=ocr_max_pages,
        dpi=200,
        lang=ocr_lang,
        pages=pages,
    )
    return (ocr_txt or "").strip()
