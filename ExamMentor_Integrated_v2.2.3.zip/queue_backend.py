"""queue_backend.py

Pluggable job dispatch for ExamMentor.

Backends:
- thread (default): in-process ThreadPoolExecutor
- rq: Redis Queue (requires redis + rq, and a running worker)

Env:
- JOB_BACKEND=thread|rq
- REDIS_URL=redis://localhost:6379/0
- RQ_QUEUE=exammentor
- JOB_TIMEOUT_SECONDS=900
"""

from __future__ import annotations

import os
from concurrent.futures import Executor
from typing import Callable, Optional


def submit_job(job_id: int, *, executor: Optional[Executor], job_func: Callable[[int], None]) -> dict:
    backend = (os.getenv("JOB_BACKEND") or "thread").strip().lower()

    if backend in ("rq", "redis", "redis-rq"):
        # Enqueue by import path to keep the payload lightweight.
        # NOTE: worker must have access to the same codebase.
        from redis import Redis  # type: ignore
        from rq import Queue  # type: ignore

        redis_url = (os.getenv("REDIS_URL") or "redis://localhost:6379/0").strip()
        qname = (os.getenv("RQ_QUEUE") or "exammentor").strip()
        timeout = int(os.getenv("JOB_TIMEOUT_SECONDS") or "900")

        conn = Redis.from_url(redis_url)
        q = Queue(qname, connection=conn)

        # Important: enqueue string path so we don't pickle heavy objects.
        q.enqueue("main._run_job", int(job_id), job_timeout=timeout)
        return {"backend": "rq", "queue": qname}

    # default: thread/in-process
    if executor is None:
        raise RuntimeError("Missing executor for thread backend")
    executor.submit(job_func, int(job_id))
    return {"backend": "thread"}
