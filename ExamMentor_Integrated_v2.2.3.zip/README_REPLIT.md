# ExamMentor – Replit quick start

## 1) Install deps
```bash
python -m pip install -r requirements.txt
```

## 2) Sanity check (optional but recommended)
```bash
bash scripts/sanity_check.sh
```

## 3) Run
### Option A (recommended)
```bash
python main.py
```

### Option B
```bash
uvicorn main:app --host 0.0.0.0 --port 3000
```

## Notes
- Replit typically exposes port **3000**.
- If you prefer a different port: set `PORT` env var.
