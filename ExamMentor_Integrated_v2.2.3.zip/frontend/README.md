# ExamMentor Frontend (React + Vite PWA)

Minimál UI skeleton a FastAPI backendhez:
- Dokumentum lista
- Feltöltés
- Job lista (polling)
- PDF Tools oldal (job alapú): compress / split / extract-text / pdf→images / images→pdf
- Törlés: dokumentum + artifact (API v1)

## Fejlesztői futtatás

### 1) Backend

```bash
cd ..
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

### 2) Frontend

```bash
cd frontend
npm install
npm run dev
```

A Vite dev proxy a `/api/v1` hívásokat a backend felé irányítja (`http://localhost:8000`).

## Konfiguráció

- `VITE_API_BASE` (opcionális): ha nem proxyn keresztül hívod a backendet.
  - pl. `VITE_API_BASE=http://localhost:8000`

## Build

```bash
npm run build
npm run preview
```
