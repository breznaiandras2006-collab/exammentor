const API_BASE = import.meta.env.VITE_API_BASE || ''

async function parseJson(res) {
  const text = await res.text()
  try {
    return text ? JSON.parse(text) : null
  } catch {
    return null
  }
}

function pickErrorMessage(data, res) {
  if (!data) return res.statusText
  // New standard API error: { ok:false, error:{message, request_id,...}}
  if (data.error && (data.error.message || data.error.code)) {
    const rid = data.error.request_id ? ` (rid: ${data.error.request_id})` : ''
    return `${data.error.message || data.error.code}${rid}`
  }
  // FastAPI default
  if (data.detail) return String(data.detail)
  if (data.message) return String(data.message)
  return res.statusText
}

export async function apiGet(path) {
  const res = await fetch(`${API_BASE}${path}`)
  const data = await parseJson(res)
  if (!res.ok) throw new Error(pickErrorMessage(data, res))
  return data
}

export async function apiPostForm(path, formData) {
  const res = await fetch(`${API_BASE}${path}`, { method: 'POST', body: formData })
  const data = await parseJson(res)
  if (!res.ok) throw new Error(pickErrorMessage(data, res))
  return data
}

export async function apiDelete(path) {
  const res = await fetch(`${API_BASE}${path}`, { method: 'DELETE' })
  const data = await parseJson(res)
  if (!res.ok) throw new Error(pickErrorMessage(data, res))
  return data
}
