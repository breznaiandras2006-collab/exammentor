import React from 'react'
import { NavLink, Route, Routes } from 'react-router-dom'
import Documents from './pages/Documents.jsx'
import Jobs from './pages/Jobs.jsx'
import PdfTools from './pages/PdfTools.jsx'

export default function App() {
  return (
    <div className="container">
      <header className="header">
        <div className="brand">ExamMentor</div>
        <nav className="nav">
          <NavLink to="/" end className={({ isActive }) => (isActive ? 'active' : '')}>Documents</NavLink>
          <NavLink to="/pdf" className={({ isActive }) => (isActive ? 'active' : '')}>PDF Tools</NavLink>
          <NavLink to="/jobs" className={({ isActive }) => (isActive ? 'active' : '')}>Jobs</NavLink>
        </nav>
      </header>

      <main className="main">
        <Routes>
          <Route path="/" element={<Documents />} />
          <Route path="/pdf" element={<PdfTools />} />
          <Route path="/jobs" element={<Jobs />} />
        </Routes>
      </main>

      <footer className="footer">
        <span className="muted">API: /api/v1 — CORS allow-origins env configurable.</span>
      </footer>
    </div>
  )
}
