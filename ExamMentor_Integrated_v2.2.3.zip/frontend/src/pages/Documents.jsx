import React, { useEffect, useMemo, useState } from 'react'
import { apiDelete, apiGet, apiPostForm } from '../api.js'

function bytes(n) {
  if (n == null) return '—'
  const kb = 1024
  const mb = kb * 1024
  if (n >= mb) return `${(n / mb).toFixed(1)} MB`
  if (n >= kb) return `${(n / kb).toFixed(1)} KB`
  return `${n} B`
}

export default function Documents() {
  const [docs, setDocs] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const [title, setTitle] = useState('')
  const [language, setLanguage] = useState('auto')
  const [file, setFile] = useState(null)
  const [uploading, setUploading] = useState(false)

  async function refresh() {
    setLoading(true)
    setError('')
    try {
      const r = await apiGet('/api/v1/documents?limit=200')
      setDocs(r.items || [])
    } catch (e) {
      setError(String(e.message || e))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    refresh()
  }, [])

  async function onUpload(e) {
    e.preventDefault()
    if (!file) return

    setUploading(true)
    setError('')
    try {
      const fd = new FormData()
      fd.set('title', title)
      fd.set('language', language)
      fd.set('pdf', file)
      await apiPostForm('/api/v1/documents', fd)
      setTitle('')
      setLanguage('auto')
      setFile(null)
      await refresh()
    } catch (e) {
      setError(String(e.message || e))
    } finally {
      setUploading(false)
    }
  }

  // Minimal tool demo: create a compress job per document
  async function runCompressJob(docId) {
    setError('')
    try {
      const fd = new FormData()
      fd.set('doc_id', String(docId))
      fd.set('mode', 'job')
      const r = await apiPostForm('/api/v1/pdf/compress', fd)
      const jid = r.job?.id
      if (jid) {
        window.location.href = `/jobs?focus=${jid}`
      }
    } catch (e) {
      setError(String(e.message || e))
    }
  }

  async function deleteDoc(docId) {
    if (!window.confirm(`Delete document #${docId}? This will also delete its artifacts and jobs.`)) return
    setError('')
    try {
      await apiDelete(`/api/v1/documents/${docId}`)
      await refresh()
    } catch (e) {
      setError(String(e.message || e))
    }
  }

  return (
    <div className="stack">
      <section className="card">
        <h2>Upload PDF</h2>
        <form onSubmit={onUpload} className="form">
          <label>
            Title (optional)
            <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Psychology lecture" />
          </label>
          <label>
            Language
            <select value={language} onChange={(e) => setLanguage(e.target.value)}>
              <option value="auto">auto</option>
              <option value="hu">hu</option>
              <option value="en">en</option>
            </select>
          </label>
          <label>
            File
            <input type="file" accept="application/pdf" onChange={(e) => setFile(e.target.files?.[0] || null)} />
          </label>
          <button disabled={uploading || !file}>{uploading ? 'Uploading…' : 'Upload'}</button>
        </form>
        {error ? <div className="error">{error}</div> : null}
      </section>

      <section className="card">
        <div className="row">
          <h2>Documents</h2>
          <button onClick={refresh} disabled={loading}>Refresh</button>
        </div>
        {loading ? <div className="muted">Loading…</div> : null}
        {!loading && docs.length === 0 ? <div className="muted">No documents yet.</div> : null}

        <div className="table">
          <div className="thead">
            <div>ID</div>
            <div>Title</div>
            <div>Pages</div>
            <div>Actions</div>
          </div>
          {docs.map((d) => (
            <div className="trow" key={d.id}>
              <div>#{d.id}</div>
              <div>{d.title || d.original_name}</div>
              <div className="muted">{d.pages ?? '—'}</div>
              <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
                <a href={d.download_url || `/api/v1/documents/${d.id}/download`} target="_blank" rel="noreferrer">Download</a>
                <button onClick={() => runCompressJob(d.id)}>Compress (job)</button>
                <button className="danger" onClick={() => deleteDoc(d.id)}>Delete</button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="card">
        <h2>Next</h2>
        <div className="muted">
          Tipp: használd a <b>PDF Tools</b> oldalt (navbar), ott van split / text export / PDF→images / images→pdf job módban.
        </div>
      </section>
    </div>
  )
}
