import React, { useEffect, useMemo, useRef, useState } from 'react'
import { apiDelete, apiGet, apiPostForm } from '../api.js'

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms))
}

export default function PdfTools() {
  const [docs, setDocs] = useState([])
  const [selected, setSelected] = useState('')
  const [artifacts, setArtifacts] = useState([])
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')
  const [status, setStatus] = useState('')
  const [job, setJob] = useState(null)

  // tool params
  const [ranges, setRanges] = useState('')
  const [maxPages, setMaxPages] = useState(25)
  const [dpi, setDpi] = useState(150)
  const [fmt, setFmt] = useState('png')

  // images->pdf
  const [outName, setOutName] = useState('images')
  const [imgFiles, setImgFiles] = useState([])

  const stopRef = useRef(false)

  async function refreshDocs() {
    const r = await apiGet('/api/v1/documents?limit=200')
    const items = r.items || []
    setDocs(items)
    if (!selected && items[0]?.id) setSelected(String(items[0].id))
  }

  async function refreshArtifacts(docId = selected) {
    if (!docId) {
      setArtifacts([])
      return
    }
    const r = await apiGet(`/api/v1/artifacts?document_id=${encodeURIComponent(docId)}&limit=200`)
    setArtifacts(r.items || [])
  }

  useEffect(() => {
    refreshDocs().catch((e) => setErr(String(e.message || e)))
    return () => {
      stopRef.current = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    refreshArtifacts().catch(() => {})
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected])

  async function pollJob(jobId) {
    setStatus(`Job #${jobId} queued…`)
    for (let i = 0; i < 200; i++) {
      if (stopRef.current) return
      const r = await apiGet(`/api/v1/jobs/${jobId}`)
      const j = r.item
      setJob(j)
      if (j.status === 'succeeded' || j.status === 'failed') {
        setStatus(`Job #${jobId}: ${j.status}`)
        await refreshArtifacts()
        return
      }
      setStatus(`Job #${jobId}: ${j.status}…`)
      await sleep(800)
    }
    setStatus(`Job #${jobId}: timeout (still running?)`)
  }

  async function runJob(endpoint, extraForm = {}) {
    if (!selected) {
      setErr('Select a document first.')
      return
    }
    setErr('')
    setBusy(true)
    setJob(null)
    try {
      const fd = new FormData()
      fd.set('doc_id', String(selected))
      fd.set('mode', 'job')
      Object.entries(extraForm).forEach(([k, v]) => fd.set(k, String(v ?? '')))
      const r = await apiPostForm(endpoint, fd)
      const jid = r.job?.id
      if (jid) await pollJob(jid)
    } catch (e) {
      setErr(String(e.message || e))
    } finally {
      setBusy(false)
    }
  }

  async function runImagesToPdf() {
    setErr('')
    setBusy(true)
    setJob(null)
    try {
      if (!imgFiles?.length) throw new Error('Please select at least 1 image.')
      const fd = new FormData()
      fd.set('output_name', outName || 'images')
      fd.set('mode', 'job')
      for (const f of imgFiles) fd.append('images', f)
      const r = await apiPostForm('/api/v1/pdf/images-to-pdf', fd)
      const jid = r.job?.id
      if (jid) await pollJob(jid)
    } catch (e) {
      setErr(String(e.message || e))
    } finally {
      setBusy(false)
    }
  }

  async function deleteArtifact(aid) {
    if (!aid) return
    setErr('')
    try {
      await apiDelete(`/api/v1/artifacts/${aid}`)
      await refreshArtifacts()
    } catch (e) {
      setErr(String(e.message || e))
    }
  }

  const selectedDoc = useMemo(() => docs.find((d) => String(d.id) === String(selected)), [docs, selected])

  return (
    <div className="stack">
      <section className="card">
        <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center' }}>
          <h2 style={{ margin: 0 }}>PDF Tools (Jobs)</h2>
          <button onClick={() => { refreshDocs(); refreshArtifacts(); }} disabled={busy}>Refresh</button>
        </div>

        <label style={{ marginTop: 12 }}>
          Document
          <select value={selected} onChange={(e) => setSelected(e.target.value)}>
            <option value="">— select —</option>
            {docs.map((d) => (
              <option key={d.id} value={String(d.id)}>
                #{d.id} — {d.title || d.original_name}
              </option>
            ))}
          </select>
        </label>

        {selectedDoc ? (
          <div className="muted" style={{ marginTop: 8 }}>
            Pages: {selectedDoc.pages ?? '—'} · Download: <a href={selectedDoc.download_url} target="_blank" rel="noreferrer">original</a>
          </div>
        ) : null}

        <div className="hr" />

        <div className="grid2">
          <div>
            <h3>Compress</h3>
            <button disabled={busy || !selected} onClick={() => runJob('/api/v1/pdf/compress')}>Run compress job</button>
          </div>

          <div>
            <h3>Split → ZIP</h3>
            <label>
              Ranges (e.g. 1-2, 5-7)
              <input value={ranges} onChange={(e) => setRanges(e.target.value)} placeholder="1-2, 3-5" />
            </label>
            <button disabled={busy || !selected} onClick={() => runJob('/api/v1/pdf/split', { ranges_text: ranges })}>
              Run split job
            </button>
          </div>

          <div>
            <h3>Extract text</h3>
            <label>
              Max pages
              <input type="number" min={1} max={200} value={maxPages} onChange={(e) => setMaxPages(Number(e.target.value || 25))} />
            </label>
            <button disabled={busy || !selected} onClick={() => runJob('/api/v1/pdf/extract-text', { max_pages: maxPages })}>
              Run text export job
            </button>
          </div>

          <div>
            <h3>PDF → Images ZIP</h3>
            <label>
              Ranges (optional)
              <input value={ranges} onChange={(e) => setRanges(e.target.value)} placeholder="(empty = all)" />
            </label>
            <div className="row" style={{ gap: 8 }}>
              <label style={{ flex: 1 }}>
                DPI
                <input type="number" min={72} max={300} value={dpi} onChange={(e) => setDpi(Number(e.target.value || 150))} />
              </label>
              <label style={{ flex: 1 }}>
                Format
                <select value={fmt} onChange={(e) => setFmt(e.target.value)}>
                  <option value="png">png</option>
                  <option value="jpg">jpg</option>
                </select>
              </label>
            </div>
            <button disabled={busy || !selected} onClick={() => runJob('/api/v1/pdf/pdf-to-images', { ranges_text: ranges, dpi, image_format: fmt })}>
              Run PDF→images job
            </button>
          </div>
        </div>

        <div className="hr" />

        <h3>Images → PDF</h3>
        <label>
          Output name
          <input value={outName} onChange={(e) => setOutName(e.target.value)} placeholder="images" />
        </label>
        <label>
          Select images
          <input type="file" accept="image/*" multiple onChange={(e) => setImgFiles(Array.from(e.target.files || []))} />
        </label>
        <button disabled={busy || imgFiles.length === 0} onClick={runImagesToPdf}>Run images→pdf job</button>

        {err ? <div className="alert err" style={{ marginTop: 12 }}>{err}</div> : null}
        {status ? <div className="alert" style={{ marginTop: 12 }}>{status}</div> : null}

        {job && job.download_url ? (
          <div className="alert ok" style={{ marginTop: 12 }}>
            ✅ Ready: <a href={job.download_url} target="_blank" rel="noreferrer">Download output</a>
          </div>
        ) : null}
      </section>

      <section className="card">
        <h2>Artifacts</h2>
        <div className="muted">Generated outputs for the selected document.</div>
        <div className="table" style={{ marginTop: 12 }}>
          <div className="thead">
            <div>ID</div>
            <div>Kind</div>
            <div>Name</div>
            <div>Actions</div>
          </div>
          {artifacts.map((a) => (
            <div className="trow" key={a.id}>
              <div>#{a.id}</div>
              <div className="muted">{a.kind}</div>
              <div>{a.original_name}</div>
              <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
                <a href={a.download_url} target="_blank" rel="noreferrer">Download</a>
                <button className="danger" onClick={() => deleteArtifact(a.id)}>Delete</button>
              </div>
            </div>
          ))}
          {artifacts.length === 0 ? <div className="muted" style={{ padding: 12 }}>No artifacts.</div> : null}
        </div>
      </section>
    </div>
  )
}
