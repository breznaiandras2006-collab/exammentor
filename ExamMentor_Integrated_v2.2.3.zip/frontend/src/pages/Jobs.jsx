import React, { useEffect, useRef, useState } from 'react'
import { apiGet } from '../api.js'

function badgeClass(status) {
  const s = (status || '').toLowerCase()
  if (s === 'succeeded') return 'badge ok'
  if (s === 'failed') return 'badge err'
  if (s === 'running') return 'badge run'
  return 'badge'
}

export default function Jobs() {
  const [items, setItems] = useState([])
  const [err, setErr] = useState(null)
  const [loading, setLoading] = useState(false)
  const timer = useRef(null)
  const focusId = useRef(null)

  async function load() {
    setLoading(true)
    setErr(null)
    try {
      const data = await apiGet('/api/v1/jobs?limit=100')
      setItems((data && data.items) || [])
    } catch (e) {
      setErr(e?.message || String(e))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    try {
      const p = new URLSearchParams(window.location.search)
      const f = p.get('focus')
      focusId.current = f ? String(f) : null
    } catch {
      focusId.current = null
    }
    load()
    timer.current = setInterval(load, 2000)
    return () => timer.current && clearInterval(timer.current)
  }, [])

  return (
    <div className="card">
      <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center' }}>
        <h2 style={{ margin: 0 }}>Jobs</h2>
        <button className="btn" onClick={load} disabled={loading}>Frissítés</button>
      </div>

      {err && <div className="alert err">{err}</div>}

      <div className="muted" style={{ marginTop: 8 }}>
        Auto-refresh: 2s (MVP)
      </div>

      <div className="tableWrap">
        <table className="table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Kind</th>
              <th>Status</th>
              <th>Doc</th>
              <th>Download</th>
            </tr>
          </thead>
          <tbody>
            {items.map((j) => (
              <tr key={j.id} style={focusId.current && String(j.id) === focusId.current ? { outline: '2px solid currentColor' } : undefined}>
                <td>#{j.id}</td>
                <td className="muted">{j.kind}</td>
                <td><span className={badgeClass(j.status)}>{j.status}</span></td>
                <td className="muted">{j.document_id ?? '—'}</td>
                <td>
                  {j.download_url ? (
                    <a href={j.download_url} target="_blank" rel="noreferrer">Download</a>
                  ) : (
                    <span className="muted">—</span>
                  )}
                </td>
              </tr>
            ))}
            {items.length === 0 && (
              <tr>
                <td colSpan={5} className="muted">Nincs job.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
