# DEPLOY.md

## 1) Lokális futtatás (MVP)

```bash
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

Alapértelmezés: **in-process thread** job futtatás (`JOB_BACKEND=thread`).

## 2) Lokális futtatás Redis + RQ workerrel (prod-közelibb)

### 2.1 Redis indítása

- Docker:

```bash
docker run --rm -p 6379:6379 redis:7-alpine
```

### 2.2 Web backend

```bash
export JOB_BACKEND=rq
export REDIS_URL=redis://localhost:6379/0
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

### 2.3 Worker

```bash
export JOB_BACKEND=rq
export REDIS_URL=redis://localhost:6379/0
python worker_rq.py
```

## 3) Docker (web + worker + redis)

```bash
docker compose up --build
```

## 4) Env változók

- `LOG_LEVEL` (default: `INFO`)
- `CORS_ALLOW_ORIGINS` (default: `*`)
- `MAX_UPLOAD_MB` (default: `100`)
- `ARTIFACT_RETENTION_DAYS` (default: `7`) – régi kimenetek automatikus takarítása bootkor
- `JOB_WORKERS` (thread backendnél, default: `2`)
- `JOB_BACKEND` (`thread` | `rq`, default: `thread`)
- `REDIS_URL` (default: `redis://localhost:6379/0`)
- `RQ_QUEUE` (default: `exammentor`)
- `JOB_TIMEOUT_SECONDS` (default: `900`)

## 5) PWA (Android) – minimál MVP út

1) Backend publikus URL-en (HTTPS) vagy `localhost`.
2) Nyisd meg Chrome-ban a webappot (React frontend vagy a FastAPI UI).
3) Menü → **Add to Home screen** (Telepítés / Parancsikon).

Megjegyzés: a "valódi" PWA install általában HTTPS-t kér.

Részletes döntési út: lásd `ANDROID.md`.

## 6) Desktop wrapper (Tauri – javasolt)

Terv (MVP): a `frontend/` React appot csomagoljuk Tauri-val.

Rövid lépések:

```bash
cd frontend
npm install
npm run build

# Tauri init (egyszer):
# npm create tauri-app@latest
```

A Tauri projektben a build outputot (`frontend/dist`) kell beállítani web assetként.

Skeleton: lásd `desktop/README.md`.
