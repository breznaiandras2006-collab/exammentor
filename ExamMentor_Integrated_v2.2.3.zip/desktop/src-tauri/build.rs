fn main() {
  tauri_build::build()
}
