# Desktop (Tauri) skeleton

Cél: a **frontend PWA** becsomagolása desktop app-ba (Windows/macOS/Linux).

## Követelmények
- Node.js + npm
- Rust toolchain (Windowson: Visual Studio Build Tools)
- Tauri CLI

## Dev mód (frontend dev server)

1) Backend:
```bash
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

2) Frontend:
```bash
cd ../frontend
npm install
npm run dev
```

3) Desktop:
```bash
cd ../desktop
npm install
npm run tauri:dev
```

## Build (distributable)
```bash
cd ../desktop
npm install
npm run tauri:build
```

- A build a `../frontend/dist` tartalmat használja.
- Windows output tipikusan: `desktop/src-tauri/target/release/bundle/`.

## Megjegyzés
Ez egy **skeleton**, a tényleges Tauri init/projektgenerálást éles környezetben érdemes lefuttatni.
