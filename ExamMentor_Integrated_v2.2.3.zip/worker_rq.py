"""worker_rq.py

Run a Redis Queue worker for ExamMentor jobs.

Usage:
  export JOB_BACKEND=rq
  export REDIS_URL=redis://localhost:6379/0
  python worker_rq.py

The worker will execute enqueued functions such as: main._run_job(job_id)
"""

from __future__ import annotations

import os


def main() -> None:
    from redis import Redis  # type: ignore
    from rq import Worker, Queue, Connection  # type: ignore

    redis_url = (os.getenv("REDIS_URL") or "redis://localhost:6379/0").strip()
    qname = (os.getenv("RQ_QUEUE") or "exammentor").strip()

    conn = Redis.from_url(redis_url)
    q = Queue(qname, connection=conn)

    print(f"[worker] Redis: {redis_url}")
    print(f"[worker] Queue: {qname}")

    with Connection(conn):
        w = Worker([q])
        w.work(with_scheduler=False)


if __name__ == "__main__":
    main()
