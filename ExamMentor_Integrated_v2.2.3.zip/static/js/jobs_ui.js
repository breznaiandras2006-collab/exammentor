/* jobs_ui.js
   Minimal job-mode demo for the built-in HTML UI.
   Flow: POST /api/v1/pdf/... (mode=job) -> poll /api/v1/jobs/{id} -> download.
*/

(function () {
  const root = document.getElementById('job-demo');
  if (!root) return;

  const docSelect = document.getElementById('job-doc');
  const ranges = document.getElementById('job-ranges');
  const dpi = document.getElementById('job-dpi');
  const fmt = document.getElementById('job-fmt');
  const statusEl = document.getElementById('job-demo-status');

  const buttons = root.querySelectorAll('button[data-job]');
  let pollTimer = null;

  function setStatus(msg) {
    if (!statusEl) return;
    statusEl.textContent = msg;
  }

  async function postJob(endpoint, formData) {
    formData.set('mode', 'job');

    const res = await fetch(endpoint, { method: 'POST', body: formData });
    const data = await res.json().catch(() => null);
    if (!res.ok) {
      const detail = (data && (data.detail || data.message)) ? (data.detail || data.message) : res.statusText;
      throw new Error(detail);
    }
    if (!data || !data.job) throw new Error('Missing job payload');
    return data.job;
  }

  async function getJob(jobId) {
    const res = await fetch(`/api/v1/jobs/${jobId}`);
    const data = await res.json().catch(() => null);
    if (!res.ok) {
      const detail = (data && (data.detail || data.message)) ? (data.detail || data.message) : res.statusText;
      throw new Error(detail);
    }
    return data && data.item ? data.item : null;
  }

  function stopPoll() {
    if (pollTimer) {
      clearInterval(pollTimer);
      pollTimer = null;
    }
  }

  function startPoll(jobId) {
    stopPoll();

    const jobUrl = `/api/v1/jobs/${jobId}`;
    setStatus(`⏳ Job #${jobId} létrehozva. Polling: ${jobUrl}`);

    let ticks = 0;
    pollTimer = setInterval(async () => {
      ticks += 1;
      try {
        const job = await getJob(jobId);
        if (!job) {
          setStatus(`❌ Job #${jobId} nem található.`);
          stopPoll();
          return;
        }

        const st = job.status || 'queued';
        if (st === 'queued' || st === 'running') {
          setStatus(`⏳ Job #${jobId} állapot: ${st} (poll #${ticks})`);
          return;
        }

        if (st === 'failed') {
          setStatus(`❌ Job #${jobId} FAILED. Error: ${job.error || '(n/a)'}`);
          stopPoll();
          return;
        }

        if (st === 'succeeded') {
          const dl = job.download_url || (job.artifact_id ? `/artifacts/${job.artifact_id}/download` : null);
          setStatus(`✅ Job #${jobId} kész. Letöltés: ${dl || '(n/a)'}\n\nTipp: az artifact lista is frissül a lap alján.`);
          if (dl) {
            // open download in a new tab (browser will download)
            window.open(dl, '_blank');
          }
          stopPoll();
          return;
        }

        setStatus(`ℹ️ Job #${jobId} ismeretlen állapot: ${st}`);
      } catch (err) {
        setStatus(`❌ Poll error: ${err && err.message ? err.message : err}`);
        // keep polling (transient)
      }
    }, 1200);
  }

  async function handleClick(kind) {
    const docId = (docSelect && docSelect.value) ? docSelect.value : '';
    if (kind !== 'images_to_pdf' && !docId) {
      setStatus('❌ Először válassz dokumentumot.');
      return;
    }

    try {
      let job;
      if (kind === 'compress') {
        const fd = new FormData();
        fd.set('doc_id', docId);
        job = await postJob('/api/v1/pdf/compress', fd);
      } else if (kind === 'split') {
        const fd = new FormData();
        fd.set('doc_id', docId);
        fd.set('ranges_text', (ranges && ranges.value) ? ranges.value : '');
        job = await postJob('/api/v1/pdf/split', fd);
      } else if (kind === 'extract') {
        const fd = new FormData();
        fd.set('doc_id', docId);
        fd.set('max_pages', '25');
        job = await postJob('/api/v1/pdf/extract-text', fd);
      } else if (kind === 'images') {
        const fd = new FormData();
        fd.set('doc_id', docId);
        fd.set('ranges_text', (ranges && ranges.value) ? ranges.value : '');
        fd.set('dpi', (dpi && dpi.value) ? dpi.value : '150');
        fd.set('image_format', (fmt && fmt.value) ? fmt.value : 'png');
        job = await postJob('/api/v1/pdf/pdf-to-images', fd);
      } else {
        setStatus('❌ Ismeretlen művelet.');
        return;
      }

      if (!job || !job.id) {
        setStatus('❌ Hibás job válasz.');
        return;
      }

      startPoll(job.id);
    } catch (err) {
      setStatus(`❌ Hiba: ${err && err.message ? err.message : err}`);
    }
  }

  buttons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const kind = btn.getAttribute('data-job');
      handleClick(kind);
    });
  });

  window.addEventListener('beforeunload', stopPoll);
})();
