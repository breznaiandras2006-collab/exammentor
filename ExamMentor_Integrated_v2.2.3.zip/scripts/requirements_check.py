"""Dependency check (Phase 1).

- Fails if REQUIRED modules are missing.
- Only warns for OPTIONAL modules.

This keeps Phase 1 "bootable" even if heavy deps (OCR/RQ/Speech) aren't installed.
"""

from __future__ import annotations

import importlib

REQUIRED = [
    "fastapi",
    "uvicorn",
    "jinja2",
    # package name: python-multipart, import name: multipart
    "multipart",
    "pypdf",
    "docx",  # python-docx
    "reportlab",
    "PIL",  # Pillow
    "requests",
]

OPTIONAL = [
    "fitz",  # PyMuPDF (OCR/advanced extraction)
    "pdfplumber",  # better text extraction
    "redis",
    "rq",
    "faster_whisper",
]


def _check(mod: str) -> bool:
    try:
        importlib.import_module(mod)
        return True
    except Exception:
        return False


missing_req = [m for m in REQUIRED if not _check(m)]

print("Required:")
for m in REQUIRED:
    print(f"  {m}:", "OK" if m not in missing_req else "MISSING")

print("Optional:")
for m in OPTIONAL:
    print(f"  {m}:", "OK" if _check(m) else "missing")

if missing_req:
    raise SystemExit(f"Missing required modules: {missing_req}")
