"""Minimal smoke test using FastAPI TestClient.

Goal: catch import errors + missing critical routes without needing external services.

Run from project root:
  python scripts/smoke_test.py
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Iterable

from fastapi.testclient import TestClient

# Ensure project root is on sys.path when this script is run as a file.
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def ok_status(code: int) -> bool:
    return code in (200, 204, 302, 303, 307, 308)


def main() -> None:
    # Ensure DB schema exists even if app startup doesn't run in this execution context.
    try:
        from db import init_db  # type: ignore
        init_db()
    except Exception:
        # If DB init fails, we still want to see it via the route tests.
        pass

    from main import app  # type: ignore

    routes: Iterable[str] = [
        "/",
        "/favicon.ico",
        "/health",
        "/api/v1/health",
        "/documents",
        "/notes",
        "/notes/new",
        "/study",
        "/study/cards",
        "/study/stats",
        "/pdf-tools",
        "/settings",
        "/onboarding",
        # Optional/placeholder module entrypoints
        "/ocr-jobs",
        "/ppt-generator",
        "/speech-to-text",
    ]

    failures = []
    with TestClient(app) as client:
        for path in routes:
            try:
                r = client.get(path, allow_redirects=False)
                if not ok_status(r.status_code):
                    failures.append((path, r.status_code, (r.text or "")[:200]))
            except Exception as e:
                failures.append((path, "EXC", repr(e)))

        # Image upload endpoint should exist.
        # If Pillow is missing, endpoint should respond with a clear error (no crash).
        try:
            r = client.post("/api/uploads/image", files={"file": ("x.png", b"", "image/png")})
            if r.status_code >= 500 and "Traceback" in (r.text or ""):
                failures.append(("/api/uploads/image", r.status_code, "traceback"))
        except Exception as e:
            failures.append(("/api/uploads/image", "EXC", repr(e)))

    if failures:
        print("❌ smoke failures:")
        print(json.dumps(failures, indent=2, ensure_ascii=False))
        raise SystemExit(1)

    print("✅ smoke ok")


if __name__ == "__main__":
    main()
