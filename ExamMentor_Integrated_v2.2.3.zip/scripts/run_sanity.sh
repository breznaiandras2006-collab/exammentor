#!/usr/bin/env bash
set -euo pipefail

# Backwards compatible entrypoint (Phase 1)
bash scripts/sanity_check.sh
