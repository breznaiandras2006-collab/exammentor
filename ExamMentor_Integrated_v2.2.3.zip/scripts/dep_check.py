"""Best-effort dependency check.

Doesn't fail the build for optional deps; prints a report.
"""
import importlib

required = ['fastapi', 'jinja2', 'pypdf']
optional = ['fitz', 'PIL', 'redis', 'rq']

def check(mod: str):
    try:
        importlib.import_module(mod)
        return True
    except Exception:
        return False

print('Required:')
for m in required:
    print(f'  {m}:', 'OK' if check(m) else 'MISSING')

print('Optional:')
for m in optional:
    print(f'  {m}:', 'OK' if check(m) else 'missing')
