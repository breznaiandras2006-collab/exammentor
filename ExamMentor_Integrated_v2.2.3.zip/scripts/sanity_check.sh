#!/usr/bin/env bash
set -euo pipefail

# Phase 1 sanity pack — stable, dependency-light checks

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

echo "===> requirements check"
python scripts/requirements_check.py

echo "===> compileall"
python scripts/compileall_check.py

echo "===> smoke test (FastAPI TestClient)"
python scripts/smoke_test.py

echo "✅ sanity ok"
