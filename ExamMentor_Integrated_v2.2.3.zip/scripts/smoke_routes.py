"""Lightweight smoke test that does NOT require running uvicorn.

- Imports main.py
- Checks app instantiation
- Verifies that core routes exist

Run: python scripts/smoke_routes.py
"""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

try:
    import main  # type: ignore
except Exception as e:
    print('❌ Failed to import main:', e)
    sys.exit(1)

app = getattr(main, 'app', None)
if app is None:
    print('❌ main.app missing')
    sys.exit(1)

paths = {getattr(r, 'path', None) for r in app.router.routes}
paths.discard(None)

required = [
    '/',
    '/documents',
    '/notes',
    '/pdf-tools',
    '/settings',
    '/study',
    '/ask',
    '/api/v1/health',
    '/api/v1/jobs',
]

missing = [p for p in required if p not in paths]
if missing:
    print('❌ Missing required routes:', missing)
    print('Known sample routes:', sorted(list(paths))[:60])
    sys.exit(1)

print('✅ smoke ok')
print('Routes checked:', ', '.join(required))
