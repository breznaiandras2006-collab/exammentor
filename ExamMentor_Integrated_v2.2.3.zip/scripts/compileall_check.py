import compileall, sys
ok = compileall.compile_dir('.', quiet=1)
if not ok:
    print('❌ compileall failed')
    sys.exit(1)
print('✅ compileall ok')
