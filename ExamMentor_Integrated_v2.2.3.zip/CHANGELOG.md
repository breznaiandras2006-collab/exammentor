# CHANGELOG

## v2.2.3 (Hotfix: Notes + Study route aliases) — 2026-01-08

### Fixed
- **/notes/new 500**: the "new note" page now passes a safe default `note` object + `mode="new"` to the template (prevents Jinja `UndefinedError: 'note' is undefined`).
- **/notes/{id}/edit form action**: edit page now sets `mode="edit"`, so the form posts to `/notes/{id}/edit` (was accidentally posting to `/notes/new`).

### Added
- **Legacy Study endpoints** to avoid 404s from older templates:
  - `POST /study/generate` → redirects to `/study/quiz` (or `/study?msg=not_enabled` if backend not wired)
  - `GET /study/cards`, `GET /study/session`, `GET /study/stats` → user-friendly redirects
- **/favicon.ico** route returning `204` when missing (reduces log noise).

### Changed
- **Smoke test** now checks: `/favicon.ico`, `/notes/new`, `/study/cards`, `/study/stats`.

## v2.2.2 (Replit packaging + sanity fix) — 2026-01-08

### Fixed
- **ZIP root layout**: project files are now at the ZIP root (no nested `Python2/` folder), so `pip install -r requirements.txt`, `bash scripts/sanity_check.sh`, and `uvicorn main:app ...` work immediately after import.
- **Replit run compatibility**: `main.py` now has a `__main__` entrypoint so `python main.py` starts the server (port from `PORT`/`REPLIT_PORT`, default `3000`).
- **Sanity dependency check**: `scripts/requirements_check.py` now checks the correct import name for `python-multipart` (`multipart`).

## v2.2.1 (Phase 1 completion patch) — 2026-01-08

### Added
- **Requirements split (minimal + optional)**:
  - `requirements.txt` = minimal bootable runtime (no Redis/RQ, no pdfplumber)
  - `requirements_optional_rq.txt` = Redis/RQ job backend
  - `requirements_optional_pdf.txt` = pdfplumber + PyMuPDF (better extraction/OCR helpers)
  - `requirements_speech.txt` = faster-whisper optional STT
- **Sanity pack names aligned** with the spec:
  - `scripts/sanity_check.sh`
  - `scripts/smoke_test.py` (FastAPI TestClient)
- **Legacy health endpoint alias**: `/health` → `/api/v1/health`

### Changed
- `scripts/run_sanity.sh` now delegates to `scripts/sanity_check.sh`.
- `scripts/requirements_check.py` now fails only for required deps; optional deps are warnings.

## v2.2 (Phase 1 finish) — 2026-01-08

### Added
- **Route blocks (non-crashing placeholders)** for Translation, PPT generator, Speech-to-text, and OCR dashboards.
- **Note image upload API**: `POST /api/uploads/image` with safe static mount at `/uploads/images/...`.
- **DB schema expansion (with safe migrations)**:
  - `notes`: `body_format`, `updated_at`, `version`, `last_client_rev`
  - New: `note_versions`, `quiz_sessions`, `quiz_attempts`, `card_bank`, `card_stats`, `user_progress`
  - Optional: `ocr_jobs` extension table
- **Unified `tools.py`**: combined PDF conversions + rotate + OCR helpers (optional deps).
- **Sanity scripts**: route smoke test + compileall check.

### Changed
- `main.py`: integrated route blocks + template existence checks to avoid crash when a module UI isn’t present yet.

### Fixed
- Reduced hard-crash risk by converting several missing-module situations into clear placeholder pages.
