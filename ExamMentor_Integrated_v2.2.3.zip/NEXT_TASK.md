# NEXT_TASK.md

## Következő 5 feladat (prioritás szerint) — Phase 2 (feature wiring)

1) **Study/Quiz backend bekötés (QuizQuality v4)** 🧠
   - `POST /study/generate` valódi generálás (doc → card_bank) + `GET /study/cards`
   - `quiz_sessions` + `quiz_attempts` + `user_progress` írása
   - UI: /study oldalon „Generate” után kártyák listája + „Start quiz” flow

2) **Notes Rich Editor integráció** ✍️🖼️
   - `templates/note_edit.html` csere rich editor verzióra
   - képfeltöltés: `POST /api/uploads/image` + resize/delete UI
   - `body_format` kezelése (html/markdown) + safe sanitize

3) **AI Translation v4 bekötés (export styling + mini CI)** 🌍
   - `/translate` UI + SSE/progress + export: txt/docx/pdf
   - optional deps fallback (no-crash, „install helper”)

4) **Speech-to-Text v3 bekötés (optional deps + job mode)** 🎙️
   - `/speech-to-text` UI: upload → job → transcript → note
   - `requirements_speech.txt` alapján best-effort install

5) **CloudSync v1.3 + Monetization MVP v3 (feature flags)** ☁️💳
   - sync endpointok összehangolása `notes.updated_at/version/last_client_rev` mezőkkel
   - quota hook-ok + upsell/paywall modal csak flaggel
