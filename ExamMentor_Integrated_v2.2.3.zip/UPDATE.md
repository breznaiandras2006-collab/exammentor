# UPDATE.md

**Dátum:** 2026-01-07

---

**Hotfix kiegészítés:** 2026-01-08 (v2.2.3) 🩹

- Javítva `/notes/new` 500: a template most mindig kap `note` + `mode` változókat.
- Javítva `/notes/{id}/edit` form action: `mode="edit"` hozzáadva, így nem hoz létre új jegyzetet szerkesztés helyett.
- Study UI kompatibilitás: `POST /study/generate` + legacy alias route-ok (`/study/cards`, `/study/session`, `/study/stats`) → redirect (nincs 404).
- `/favicon.ico` fallback 204.
- `scripts/smoke_test.py` bővítve ezekre a kritikus útvonalakra.

## Mit csináltam ebben a körben

### 0) API hibakezelés + request ID (egységes) 🧷
- `main.py`
  - `X-Request-Id` middleware (request headerből átvesszük, különben generáljuk)
  - egységes API error forma `{/api/...}` útvonalon:
    - `{"ok": false, "error": {"code", "message", "request_id", "details"}}`
  - exception handler:
    - `HTTPException` → `http_error`
    - `RequestValidationError` → `validation_error`
    - egyéb → `internal_error`

### 1) Dokumentum / artifact lifecycle (törlés + cleanup policy) 🗑️
- `db.py`
  - `detach_artifact_from_jobs`, `delete_artifact_row`
  - `list_artifacts_older_than(days)` (job által referált artifactok kizárva)
  - `detach_document_from_notes`, `delete_jobs_for_document`, `delete_document_row`
- `main.py`
  - `DELETE /api/v1/artifacts/{id}` (file + DB)
  - `DELETE /api/v1/documents/{id}` (notes detach + artifacts + jobs + file + DB)
  - `ARTIFACT_RETENTION_DAYS` (default 7)
  - bootkor best-effort cleanup + manuál:
    - `POST /api/v1/maintenance/cleanup`

### 2) Job polling minta a meglévő HTML UI-ban 🧪
- `templates/pdf_tools.html`: új **„Job mód (API + polling)”** blokk.
- `static/js/jobs_ui.js`: kliens oldali minta flow:
  - `POST /api/v1/pdf/... (mode=job)`
  - `GET /api/v1/jobs/{id}` polling
  - kész állapotnál letöltési link (artifact)

### 3) Valódi queue opció (Redis + RQ) 🚚
- `queue_backend.py`: **pluggable** job dispatch:
  - `JOB_BACKEND=thread` (default, in-process)
  - `JOB_BACKEND=rq` (Redis Queue)
- `worker_rq.py`: külön worker process a queue feldolgozásához.
- `requirements.txt`: hozzáadva `redis`, `rq`.

### 4) Nagy fájlok stabilabb kezelése 🧱
- `MAX_UPLOAD_MB` (default: 100MB) limit.
- Streaming mentés:
  - `/documents/upload` (HTML)
  - `/api/v1/documents` (API)
  - job input mentés képekhez (`_store_job_input`)
- SQLite multi-process barátabb beállítások:
  - `PRAGMA journal_mode=WAL`, `synchronous=NORMAL`, `foreign_keys=ON` (`db.py`).

### 5) Frontend: PDF Tools page + több job típus 🧩
- `frontend/src/pages/PdfTools.jsx`
  - compress / split (ZIP) / extract-text / pdf→images / images→pdf (minden job módban)
  - polling + kész állapotnál letöltési link
  - artifact lista + törlés (API v1)
- `frontend/src/api.js`
  - egységes API error parsing (request_id megjelenítése)
  - `apiDelete`

### 6) Frontend cross-platform alap (React + Vite PWA) 📱💻
- `frontend/`:
  - Dokumentum lista + feltöltés
  - Job lista (polling)
  - PDF Tools oldal
  - Dokumentum törlés (API v1)
- Vite dev proxy: `/api/v1` → `http://localhost:8000`.

### 7) Desktop wrapper skeleton (Tauri) 💻
- `desktop/` (skeleton): `src-tauri` + `tauri.conf.json` + README

### 8) Android csomagolási stratégia (PWA vs Capacitor) 📱
- `ANDROID.md`: fixált MVP irány (PWA-first) + későbbi Capacitor guide

### 9) Packaging / deploy dokumentáció 📦
- `DEPLOY.md`: local run, Redis+worker, Docker compose, env lista, PWA/desktop irány.
- `DEPLOY.md`: új env: `ARTIFACT_RETENTION_DAYS` + linkek `ANDROID.md` / `desktop/README.md`
- `Dockerfile` + `docker-compose.yml`: web + worker + redis.

## Röviden: “kész-e már?” ✅
Cross-platform MVP irányhoz: **igen**.
- Backend: API + job + queue opció + stabil feltöltés + lifecycle + egységes hibák.
- Frontend: PWA skeleton + PDF Tools + job polling.

A következő szint a „production-polish”: auth, rate-limit, fájl/lifecycle menedzsment, és a Tauri/Android wrapper tényleges projekt inicializálása.
